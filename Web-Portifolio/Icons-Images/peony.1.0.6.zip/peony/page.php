<?php
/**
 * The template for displaying all pages.
 *
 * @package peony
 */
get_header(); 

$sidebar ='none';
$enable_page_title_bar     = absint(peony_option('enable_page_title_bar'));
$page_title_pos            = esc_attr(peony_option('page_title_pos'));
$display_breadcrumb        = esc_attr(peony_option('display_breadcrumb'));
$breadcrumb_menu_prefix    = esc_attr(peony_option('breadcrumb_menu_prefix',''));
$breadcrumb_menu_separator = esc_attr(peony_option('breadcrumb_menu_separator','/'));

$left_sidebar              = esc_attr(peony_option('left_sidebar_pages'));
$right_sidebar             = esc_attr(peony_option('right_sidebar_pages'));

$container = 'container';

if( $left_sidebar !='' )
  $sidebar ='left';
if( $right_sidebar !='' )
  $sidebar ='right';
if( $left_sidebar !='' && $right_sidebar !='' )
  $sidebar ='both';

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<?php if( $enable_page_title_bar == '1' ):?>
<section class="page-title-bar title-<?php echo $page_title_pos;?> no-subtitle peony_enable_page_title_bar">
            <div class="container">
                <hgroup class="page-title text-light">
                    <h1><?php the_title();?></h1>
                </hgroup>
                <?php if( $display_breadcrumb == '1' ):?>
                <?php peony_get_breadcrumb(array("before"=>"<div class='breadcrumb-nav text-light peony_display_breadcrumb'>".$breadcrumb_menu_prefix,"after"=>"</div>","show_browse"=>false,"separator"=>$breadcrumb_menu_separator));?>
                <?php endif;?>
                
                <div class="clearfix"></div>            
            </div>
        </section>
<?php endif;?>
   
 <div class="post-wrap">
            <div class="<?php echo $container;?>">
                <div class="page-inner row <?php echo peony_get_content_class($sidebar);?>">
                        <div class="col-main">
             <?php while ( have_posts() ) : the_post(); ?>

		 	 <?php  get_template_part( 'content', 'page' ); ?>

		     <?php endwhile; // end of the loop. ?>
                        </div>
                       <?php if( $sidebar == 'left' || $sidebar == 'both'  ): ?>
       <div class="col-aside-left">
                        <aside class="blog-side left text-left">
                            <div class="widget-area">
                            <?php get_sidebar('pageleft');?>
                            </div>
                        </aside>
                    </div>
            <?php endif; ?>
            <?php if( $sidebar == 'right' || $sidebar == 'both'  ): ?>     
                    <div class="col-aside-right">
                        <div class="widget-area">
                           <?php get_sidebar('pageright');?>
                            </div>
                    </div>
             <?php endif; ?>
                    </div>
                </div>
            </div>
      </article>
<?php get_footer(); ?>