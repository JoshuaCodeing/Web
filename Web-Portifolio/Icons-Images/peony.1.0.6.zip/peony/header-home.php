<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
 
<?php wp_head(); ?>
</head>
<?php
 global  $post;
			  
 $layout     = esc_attr(peony_option('layout'));
 $wrapper    = '';
 $body_class = '';
 if( $layout == 'boxed' )
 $wrapper    = ' wrapper-boxed container ';
 
 $body_class .= ' homepage anime-3d';
 
 $skin = peony_option('skin');
 if( $skin == '1' )
 $body_class    .= ' dark';
?>
<body <?php body_class($body_class); ?>>
    <div class="wrapper <?php echo $wrapper;?>">   