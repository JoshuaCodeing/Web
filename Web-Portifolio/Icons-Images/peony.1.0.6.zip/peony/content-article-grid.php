<?php  
 $display_image = peony_option('archive_display_image');

 ?>
<div id="post-<?php the_ID(); ?>" <?php post_class("entry-box-wrap"); ?>>
  <?php
     $post_id = get_the_ID();
     $comments_count = wp_count_comments( $post_id );
     $featured_image = '';
	 $news_item = '';
	 $wrap_class = 'no-feature-image';
	if( $display_image == '1' && has_post_thumbnail()  ){
		$image_thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post_id ) );
		$image_full  = wp_get_attachment_image_src( get_post_thumbnail_id($post_id ), "full" );
		$featured_image = '<div class="entry-image">
										<div class="img-box figcaption-middle text-center fade-in">
											<img src="'.esc_url($image_thumb[0]).'" alt="">
											<div class="img-overlay">
												<div class="img-overlay-container">
													<div class="img-overlay-content">
														<div class="img-overlay-icons">
		                                               		<a href="'.esc_url(get_permalink()).'"><i class="fa fa-link"></i></a>
		                                                	<a href="'.esc_url($image_full[0]).'" rel="prettyPhoto"><i class="fa fa-search"></i></a>
		                                            	</div>
													</div>
												</div>
											</div>
										</div>
									</div>';
		$wrap_class = '';
		}
	
	
	$news_item .= '<div class="peony-entry-wrap '.$wrap_class.'">
									 '.$featured_image.'   
									<div class="entry-main">
										<div class="post-content-inner">
											<a href="'.esc_url(get_permalink()).'"><h2 class="entry-title">'.esc_attr(get_the_title()).'</h2></a>
											<div class="entry-summary">'.peony_get_summary().'</div>
										</div>
										<div class="entry-date text-center">'.get_the_date('d',$post_id ).'<br/>'.get_the_date('M',$post_id ).'</div>
										<div class="entry-comment text-center">
											<i class="fa fa-comment"></i><br>'.$comments_count->total_comments.'
										</div>
									</div>
								</div>';
								
		echo $news_item;
  ?>
 </div>