<?php
/**
 * Defines customizer options
 *
 */

function peony_customizer_options() {
	global $peony_sidebars,$peony_default_options , $peony_homepage_sections,$peony_default_theme_fonts;
	
	// fonts
	
	$peony_default_theme_fonts = array(

            'Arial, Helvetica, sans-serif' => 'Arial, Helvetica, sans-serif',
            "'Arial Black', Gadget, sans-serif" => "'Arial Black', Gadget, sans-serif",
            "'Bookman Old Style', serif" => "'Bookman Old Style', serif",
            "'Comic Sans MS', cursive" => "'Comic Sans MS', cursive",
            "Courier, monospace" => "Courier, monospace",
            "Garamond, serif" => "Garamond, serif",
            "Georgia, serif" => "Georgia, serif",
            "Impact, Charcoal, sans-serif" => "Impact, Charcoal, sans-serif",
            "'Lucida Console', Monaco, monospace" => "'Lucida Console', Monaco, monospace",
            "'Lucida Sans Unicode', 'Lucida Grande', sans-serif" => "'Lucida Sans Unicode', 'Lucida Grande', sans-serif",
            "'MS Sans Serif', Geneva, sans-serif" => "'MS Sans Serif', Geneva, sans-serif",
            "'MS Serif', 'New York', sans-serif" => "'MS Serif', 'New York', sans-serif",
            "'Palatino Linotype', 'Book Antiqua', Palatino, serif" => "'Palatino Linotype', 'Book Antiqua', Palatino, serif",
            "Tahoma, Geneva, sans-serif" => "Tahoma, Geneva, sans-serif",
            "'Times New Roman', Times, serif" => "'Times New Roman', Times, serif",
            "'Trebuchet MS', Helvetica, sans-serif" => "'Trebuchet MS', Helvetica, sans-serif",
            "Verdana, Geneva, sans-serif" => "Verdana, Geneva, sans-serif"
			
   );
	
	$default_theme_fonts_option[''] =  __( '-- Select Font --', 'peony' );
	foreach($peony_default_theme_fonts as $index => $value){
	$default_theme_fonts_option[$index] =  $value;
	}
	
	// font size
	$font_size =  array_combine(range(1,100,1), range(1,100,1));


 // Pull all the pages into an array
	$options_pages = array();
	$options_pages_obj = get_pages( 'sort_column=post_parent,menu_order' );
	$options_pages[''] = __( 'Select a page:', 'peony' );
	foreach ($options_pages_obj as $page) {
		$options_pages[$page->ID] = $page->post_title;
	}

 // If using image radio buttons, define a directory path
 $imagepath =  get_template_directory_uri() . '/images/';
	
 $choices =  array( 
            'yes'   => __( 'Yes', 'peony' ),
            'no' => __( 'No', 'peony' )
        );
 
  $align =  array( 
          
          'left' => __( 'Left', 'peony' ),
          'right' => __( 'Right', 'peony' ),
           'center'  => __( 'Center', 'peony' )         
        );
  
  $repeat = array( 
          
          'repeat' => __( 'Repeat', 'peony' ),
          'repeat-x'  => __( 'Repeat-x', 'peony' ),
          'repeat-y' => __( 'Repeat-y', 'peony' ),
          'no-repeat'  => __( 'No-repeat', 'peony' )
          
        );
  
  $position =  array( 
          
         'top left' => __( 'Top Left', 'peony' ),
          'top center' => __( 'Top Center', 'peony' ),
          'top right' => __( 'Top Right', 'peony' ),
           'center left' => __( 'Center Left', 'peony' ),
           'center center'  => __( 'Center Center', 'peony' ),
           'center right' => __( 'Center Right', 'peony' ),
           'bottom left'  => __( 'Bottom Left', 'peony' ),
           'bottom center'  => __( 'Bottom Center', 'peony' ),
           'bottom right' => __( 'Bottom Right', 'peony' )
            
        );
  
  $opacity   =  array_combine(range(0.1,1,0.1), range(0.1,1,0.1));
  $font_size =  array_combine(range(1,100,1), range(1,100,1));
  
  $target = array(
				  '_blank' => __( 'Open in new window', 'peony' ),
				  '_self' => __( 'Open in same window', 'peony' )
				  );
  
  
	// Stores all the controls that will be added
	$options = array();

	// Stores all the sections to be added
	$sections = array();

	// Stores all the panels to be added
	$panels = array();

	// Adds the sections to the $options array
	$options['sections'] = $sections;
	
 ##### Home Page #####
	
	$peony_homepage_sections = array(
					'slider' => __( 'Section - Slider', 'peony' ),
					'promo' => __( 'Section - Promo', 'peony' ),
					'gallery' => __( 'Section - Gallery', 'peony' ),
					'services' => __( 'Section - Services', 'peony' ),
					'recent_posts' => __( 'Section - Recent Posts', 'peony' ),
					'contact' => __( 'Section - Contact', 'peony' ),
          );
	
	
	// Section Slider
	$section = 'general-options';
	
	$sections[] = array(
		'id' => $section,
		'title' => __( 'General Options', 'peony' ),
		'priority' => '1',
		'description' => '',
		'panel' => ''
	);
	
	$options['peony_layout'] = array(
		'id' => 'peony_layout',
		'label' => __( 'Layout', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'select',
		'default' => 'wide',
		'choices' => array('wide'=>__( 'Wide', 'peony' ),'boxed'=> __( 'Boxed', 'peony' ) ),
	);	
	$options['peony_header_overlay'] = array(
		'id' => 'peony_header_overlay',
		'label' => __( 'Header Overlay', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'checkbox',
		'default' => '1',
	);
	
	
	
	$panel = 'peony-home-page';

	$panels[] = array(
		'id' => $panel,
		'title' => __( 'Home Page', 'peony' ),
		'priority' => '1'
	);
	
	// Section Slider
	$section = 'peony-section-slider';
	
	$sections[] = array(
		'id' => $section,
		'title' => $peony_homepage_sections['slider'],
		'priority' => '10',
		'description' => '',
		'panel' => $panel
	);
	
	$options['peony_section_slider_hide'] = array(
		'id' => 'peony_section_slider_hide',
		'label' => __( 'Hide Section', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'checkbox',
		'default' => '',
	);	
	
	$options['peony_slider_background_color'] = array(
		'id' => 'peony_slider_background_color',
		'label'   => __( 'Background Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '',
		'description' => __( 'Set background color for this section.', 'peony' )
	);
	
	$options['peony_slider_background_image'] = array(
		'id' => 'peony_slider_background_image',
		'label'   => __( 'Background Image', 'peony' ),
		'section' => $section,
		'type'    => 'upload',
		'default' => '',
		'description' => __( 'Upload background image for this section.', 'peony' )
	);
	
	$options['peony_slider_background_repeat'] =  array(
        'id'          => 'peony_slider_background_repeat',
        'label'       => __( 'Background Repeat', 'peony' ),
        'description' => __( 'Select how the background image repeats.', 'peony' ),
        'default'     => 'repeat',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $repeat
      );
  $options['peony_slider_background_position'] =  array(
        'id'          => 'peony_slider_background_position',
        'label'       => __( 'Background Position', 'peony' ),
        'description' => __( 'Set background image position.', 'peony' ),
        'default'     => 'top left',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $position
      );

  $options['peony_slider_title_color'] = array(
		'id' => 'peony_slider_title_color',
		'label'   => __( 'Title Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#ffffff',
		'description' => __( 'Set color for this section title.', 'peony' )
	);
	$options['peony_slider_content_color'] = array(
		'id' => 'peony_slider_content_color',
		'label'   => __( 'Content Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#ffffff',
		'description' => __( 'Set color for this section content.', 'peony' )
	);
	$options['peony_slider_title'] = array(
		'id' => 'peony_slider_title',
		'label' => __( 'Section Title', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'BANNER',
	);
	

	$options['peony_slider_id'] = array(
		'id' => 'peony_slider_id',
		'label' => __( 'Section ID', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'section-1',
	);
		
	$display_slide = array('1','1','','','');
	$slide_image   = array(
						   $imagepath.'bg1.jpg',
						   $imagepath.'bg2.jpg',
						   '',
						   '',
						   '');
	
	$slide_title    = array('Welcome to Our Website','Welcome to Our Website','','','');
	$slide_subtitle = array('Integer ultrices condimentum ultricies.','Integer ultrices condimentum ultricies.','','','');
	for( $i=0;$i<5;$i++ ){
		
		$options['peony_slider_display_'.$i] = array(
		'id' => 'peony_slider_display_'.$i,
		'label' => sprintf(__( 'Display Slide %d', 'peony' ),$i+1),
		'description' => '',
		'section' => $section,
		'type'    => 'checkbox',
		'default' => $display_slide[$i],
	    );
		
		$options['peony_slider_image_'.$i] = array(
		'id' => 'peony_slider_image_'.$i,
		'label'   => sprintf(__( 'Image %d', 'peony' ),$i+1),
		'section' => $section,
		'type'    => 'upload',
		'default' => $slide_image[$i],
		'description' => __( 'Upload background image for this slide.', 'peony' )
	);
		
		$options['peony_slider_title_'.$i] = array(
		'id' => 'peony_slider_title_'.$i,
		'label' => sprintf(__( 'Caption Title %d', 'peony' ),$i+1),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => $slide_title[$i],
	    );
		
		$options['peony_slider_subtitle_'.$i] = array(
		'id' => 'peony_slider_subtitle_'.$i,
		'label' => sprintf(__( 'Caption Subtitle %d', 'peony' ),$i+1),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => $slide_subtitle[$i],
	    );
			
 }

// Section Promo
	$section = 'peony-section-promo';
	
	$sections[] = array(
		'id' => $section,
		'title' => $peony_homepage_sections['promo'],
		'priority' => '10',
		'description' => '',
		'panel' => $panel
	);
	
	$options['peony_section_promo_hide'] = array(
		'id' => 'peony_section_promo_hide',
		'label' => __( 'Hide Section', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'checkbox',
		'default' => '',
	);	
	
	$options['peony_promo_background_color'] = array(
		'id' => 'peony_promo_background_color',
		'label'   => __( 'Background Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#D4D5DA',
		'description' => __( 'Set background color for this section.', 'peony' )
	);
	
	$options['peony_promo_background_image'] = array(
		'id' => 'peony_promo_background_image',
		'label'   => __( 'Background Image', 'peony' ),
		'section' => $section,
		'type'    => 'upload',
		'default' => '',
		'description' => __( 'Upload background image for this section.', 'peony' )
	);
	
	$options['peony_promo_background_repeat'] =  array(
        'id'          => 'peony_promo_background_repeat',
        'label'       => __( 'Background Repeat', 'peony' ),
        'description' => __( 'Select how the background image repeats.', 'peony' ),
        'default'     => 'repeat',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $repeat
      );
  $options['peony_promo_background_position'] =  array(
        'id'          => 'peony_promo_background_position',
        'label'       => __( 'Background Position', 'peony' ),
        'description' => __( 'Set background image position.', 'peony' ),
        'default'     => 'top left',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $position
      );

  $options['peony_promo_title_color'] = array(
		'id' => 'peony_promo_title_color',
		'label'   => __( 'Title Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#333333',
		'description' => __( 'Set color for this section title.', 'peony' )
	);
	$options['peony_promo_content_color'] = array(
		'id' => 'peony_promo_content_color',
		'label'   => __( 'Content Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#666666',
		'description' => __( 'Set color for this section content.', 'peony' )
	);
	
	
	$options['peony_promo_title'] = array(
		'id' => 'peony_promo_title',
		'label' => __( 'Section Title', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'About Me',
	);
	
	$options['peony_promo_sub_title'] = array(
		'id' => 'peony_promo_sub_title',
		'label' => __( 'Subtitle', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => '',
	);
	
	$options['peony_promo_id'] = array(
		'id' => 'peony_promo_id',
		'label' => __( 'Section ID', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'section-2',
	);
	
	

	$options['peony_promo_description'] = array(
		'id' => 'peony_promo_description',
		'label' => __( 'Description', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'select',
		'default' => '',
		'choices' => $options_pages,
	);
		
	
	$options['peony_promo_btn_text'] = array(
		'id' => 'peony_promo_btn_text',
		'label' => __( 'Button Text', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'MORE',
	);
	

	$options['peony_promo_btn_target'] = array(
		'id' => 'peony_promo_btn_target',
		'label' => __( 'Button Link Target', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'select',
		'choices' => $target,
		'default' => '_blank',
	);	
	
	$options['peony_promo_image'] = array(
		'id' => 'peony_promo_image',
		'label'   => __( 'Image', 'peony' ),
		'section' => $section,
		'type'    => 'upload',
		'default' => '',
		'description' => ''
	);
	
	
	
	// Section Gallery
	$section = 'peony-section-gallery';
	
	$sections[] = array(
		'id' => $section,
		'title' => $peony_homepage_sections['gallery'],
		'priority' => '10',
		'description' => '',
		'panel' => $panel
	);
	
	$options['peony_section_gallery_hide'] = array(
		'id' => 'peony_section_gallery_hide',
		'label' => __( 'Hide Section', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'checkbox',
		'default' => '',
	);	
	
	$options['peony_gallery_background_color'] = array(
		'id' => 'peony_gallery_background_color',
		'label'   => __( 'Background Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#333333',
		'description' => __( 'Set background color for this section.', 'peony' )
	);
	
	$options['peony_gallery_background_image'] = array(
		'id' => 'peony_gallery_background_image',
		'label'   => __( 'Background Image', 'peony' ),
		'section' => $section,
		'type'    => 'upload',
		'default' => '',
		'description' => __( 'Upload background image for this section.', 'peony' )
	);
	
	$options['peony_gallery_background_repeat'] =  array(
        'id'          => 'peony_gallery_background_repeat',
        'label'       => __( 'Background Repeat', 'peony' ),
        'description' => __( 'Select how the background image repeats.', 'peony' ),
        'default'     => 'repeat',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $repeat
      );
  $options['peony_gallery_background_position'] =  array(
        'id'          => 'peony_gallery_background_position',
        'label'       => __( 'Background Position', 'peony' ),
        'description' => __( 'Set background image position.', 'peony' ),
        'default'     => 'top left',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $position
      );

  $options['peony_gallery_title_color'] = array(
		'id' => 'peony_gallery_title_color',
		'label'   => __( 'Title Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#ffffff',
		'description' => __( 'Set color for this section title.', 'peony' )
	);
	$options['peony_gallery_content_color'] = array(
		'id' => 'peony_gallery_content_color',
		'label'   => __( 'Content Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#ffffff',
		'description' => __( 'Set color for this section content.', 'peony' )
	);
	
	
	$options['peony_gallery_title'] = array(
		'id' => 'peony_gallery_title',
		'label' => __( 'Section Title', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'My Works',
	);
	
	$options['peony_gallery_sub_title'] = array(
		'id' => 'peony_gallery_sub_title',
		'label' => __( 'Subtitle', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => '',
	);
	
	$options['peony_gallery_id'] = array(
		'id' => 'peony_gallery_id',
		'label' => __( 'Section ID', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'section-3',
	);
	
	

	$options['peony_gallery_description'] = array(
		'id' => 'peony_gallery_description',
		'label' => __( 'Description', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'select',
		'default' => '',
		'choices' => $options_pages,
	);
	
	$options['peony_gallery_btn_text'] = array(
		'id' => 'peony_gallery_btn_text',
		'label' => __( 'Button Text', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'MORE',
	);
		
	$options['peony_gallery_btn_target'] = array(
		'id' => 'peony_gallery_btn_target',
		'label' => __( 'Button Link Target', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'select',
		'choices' => $target,
		'default' => '_blank',
	);	
	
	 $works_image = array(
							$imagepath.'s3-1.jpg',
							$imagepath.'s3-2.jpg',
							$imagepath.'s3-3.jpg',
							);
		for( $i = 1; $i<=3; $i++ ){
		
		$options['peony_gallery_image_'.$i] = array(
		'id' => 'peony_gallery_image_'.$i,
		'label'   => sprintf(__( 'Works Image %d', 'peony' ),$i),
		'section' => $section,
		'type'    => 'upload',
		'default' => $works_image[$i-1],
		'description' => ''
	     );
		
		$options['peony_gallery_title_'.$i] = array(
		'id' => 'peony_gallery_title_'.$i,
		'label' => sprintf(__( 'Works Title %d', 'peony' ),$i),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => '0'.$i,
              );
		
		$options['peony_gallery_desc_'.$i] = array(
		'id' => 'peony_gallery_desc_'.$i,
		'label' => sprintf(__( 'Works Description %d', 'peony' ),$i),
		'description'   => __( 'Page content.', 'peony' ),
		'section' => $section,
		'type'    => 'select',
		'default' => '',
		'choices' => $options_pages,
              );
		
		$options['peony_gallery_more_text_'.$i] = array(
		'id' => 'peony_gallery_more_text_'.$i,
		'label' => sprintf(__( 'More Link Text %d', 'peony' ),$i),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'View More Details >',
              );
		
		$options['peony_gallery_btn_target_'.$i] = array(
		'id' => 'peony_gallery_btn_target_'.$i,
		'label' => __( 'Link Target', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'select',
		'choices' => $target,
		'default' => '_blank',
	);	
		
		
		}

 
// Section Services
	$section = 'peony-section-services';
	
	$sections[] = array(
		'id' => $section,
		'title' => $peony_homepage_sections['services'],
		'priority' => '10',
		'description' => '',
		'panel' => $panel
	);
	
	$options['peony_section_services_hide'] = array(
		'id' => 'peony_section_services_hide',
		'label' => __( 'Hide Section', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'checkbox',
		'default' => '',
	);	
	
	$options['peony_services_background_color'] = array(
		'id' => 'peony_services_background_color',
		'label'   => __( 'Background Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#FEFBF6',
		'description' => __( 'Set background color for this section.', 'peony' )
	);
	
	$options['peony_services_background_image'] = array(
		'id' => 'peony_services_background_image',
		'label'   => __( 'Background Image', 'peony' ),
		'section' => $section,
		'type'    => 'upload',
		'default' =>'',
		'description' => __( 'Upload background image for this section.', 'peony' )
	);
	
	$options['peony_services_background_repeat'] =  array(
        'id'          => 'peony_services_background_repeat',
        'label'       => __( 'Background Repeat', 'peony' ),
        'description' => __( 'Select how the background image repeats.', 'peony' ),
        'default'     => 'repeat',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $repeat
      );
  $options['peony_services_background_position'] =  array(
        'id'          => 'peony_services_background_position',
        'label'       => __( 'Background Position', 'peony' ),
        'description' => __( 'Set background image position.', 'peony' ),
        'default'     => 'top left',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $position
      );

  $options['peony_services_title_color'] = array(
		'id' => 'peony_services_title_color',
		'label'   => __( 'Title Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '',
		'description' => __( 'Set color for this section title.', 'peony' )
	);
	$options['peony_services_content_color'] = array(
		'id' => 'peony_services_content_color',
		'label'   => __( 'Content Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '',
		'description' => __( 'Set color for this section content.', 'peony' )
	);
	
	
	$options['peony_services_title'] = array(
		'id' => 'peony_services_title',
		'label' => __( 'Section Title', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'Services',
	);
	
	$options['peony_services_sub_title'] = array(
		'id' => 'peony_services_sub_title',
		'label' => __( 'Subtitle', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => '',
	);
	
	$options['peony_services_id'] = array(
		'id' => 'peony_services_id',
		'label' => __( 'Section ID', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'section-4',
	);
	

	 
	 $service_icon = array(
							'fa-coffee',
							'fa-cog',
							'fa-cube',
							'fa-heart-o',
							'fa-paper-plane-o',
							'fa-smile-o',
							'',
							'',
							''
							);
	 
	 
		
		$options['peony_services_columns'] =  array(
        'id'          => 'peony_services_columns',
        'label'       => __( 'Columns', 'peony' ),
        'description' => '',
        'default'     => '3',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => array(2=>2,3=>3,4=>4)
      );
		
		
	for( $i = 1; $i<=6; $i++ ){
		
		$options['peony_services_image_'.$i] = array(
		'id' => 'peony_services_image_'.$i,
		'label'   => sprintf(__( 'Service Image %d', 'peony' ),$i),
		'section' => $section,
		'type'    => 'upload',
		'default' => '',
		'description' => ''
	     );
		
		$options['peony_services_icon_'.$i] = array(
		'id' => 'peony_services_icon_'.$i,
		'label'   => sprintf(__( 'Font Awesome %d', 'peony' ),$i),
		'section' => $section,
		'type'    => 'text',
		'default' => $service_icon[$i-1],
		'description' => ''
	     );
		
		$options['peony_services_desc_'.$i] = array(
		'id' => 'peony_services_desc_'.$i,
		'label' => sprintf(__( 'Service Description %d', 'peony' ),$i),
		'description'   => __( 'Page content.', 'peony' ),
		'section' => $section,
		'type'    => 'select',
		'default' => '',
		'choices' => $options_pages,
              );
		
		}
		
	
	 // Section Recent Posts
	$section = 'peony-section-recent_posts';
	
	$sections[] = array(
		'id' => $section,
		'title' => $peony_homepage_sections['recent_posts'],
		'priority' => '10',
		'description' => '',
		'panel' => $panel
	);
	
	$options['peony_section_recent_posts_hide'] = array(
		'id' => 'peony_section_recent_posts_hide',
		'label' => __( 'Hide Section', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'checkbox',
		'default' => '',
	);	
	
	$options['peony_recent_posts_background_color'] = array(
		'id' => 'peony_recent_posts_background_color',
		'label'   => __( 'Background Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#728089',
		'description' => __( 'Set background color for this section.', 'peony' )
	);
	
	$options['peony_recent_posts_background_image'] = array(
		'id' => 'peony_recent_posts_background_image',
		'label'   => __( 'Background Image', 'peony' ),
		'section' => $section,
		'type'    => 'upload',
		'default' => '',
		'description' => __( 'Upload background image for this section.', 'peony' )
	);
	
	$options['peony_recent_posts_background_repeat'] =  array(
        'id'          => 'peony_recent_posts_background_repeat',
        'label'       => __( 'Background Repeat', 'peony' ),
        'description' => __( 'Select how the background image repeats.', 'peony' ),
        'default'     => 'repeat',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $repeat
      );
  $options['peony_recent_posts_background_position'] =  array(
        'id'          => 'peony_recent_posts_background_position',
        'label'       => __( 'Background Position', 'peony' ),
        'description' => __( 'Set background image position.', 'peony' ),
        'default'     => 'top left',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $position
      );

  $options['peony_recent_posts_title_color'] = array(
		'id' => 'peony_recent_posts_title_color',
		'label'   => __( 'Title Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#ffffff',
		'description' => __( 'Set color for this section title.', 'peony' )
	);
	$options['peony_recent_posts_content_color'] = array(
		'id' => 'peony_recent_posts_content_color',
		'label'   => __( 'Content Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '',
		'description' => __( 'Set color for this section content.', 'peony' )
	);
	
	
	$options['peony_recent_posts_title'] = array(
		'id' => 'peony_recent_posts_title',
		'label' => __( 'Section Title', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'Blog',
	);
	
	$options['peony_recent_posts_sub_title'] = array(
		'id' => 'peony_recent_posts_sub_title',
		'label' => __( 'Subtitle', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => '',
	);
	
	$options['peony_recent_posts_id'] = array(
		'id' => 'peony_recent_posts_id',
		'label' => __( 'Section ID', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'section-5',
	);
	 $options['peony_recent_posts_num'] =  array(
        'id'          => 'peony_recent_posts_num',
        'label'       => __( 'Display Num', 'peony' ),
        'description' => '',
        'default'     => '3',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => array(2=>2,3=>3,4=>4)
      );
	

	   
	 
	 // Section Contact
	$section = 'peony-section-contact';
	
	$sections[] = array(
		'id' => $section,
		'title' => $peony_homepage_sections['contact'],
		'priority' => '10',
		'description' => '',
		'panel' => $panel
	);
	
	$options['peony_section_contact_hide'] = array(
		'id' => 'peony_section_contact_hide',
		'label' => __( 'Hide Section', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'checkbox',
		'default' => '',
	);	
	
	$options['peony_contact_background_color'] = array(
		'id' => 'peony_contact_background_color',
		'label'   => __( 'Background Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '#F0F0F2',
		'description' => __( 'Set background color for this section.', 'peony' )
	);
	
	$options['peony_contact_background_image'] = array(
		'id' => 'peony_contact_background_image',
		'label'   => __( 'Background Image', 'peony' ),
		'section' => $section,
		'type'    => 'upload',
		'default' => '',
		'description' => __( 'Upload background image for this section.', 'peony' )
	);
	
	$options['peony_contact_background_repeat'] =  array(
        'id'          => 'peony_contact_background_repeat',
        'label'       => __( 'Background Repeat', 'peony' ),
        'description' => __( 'Select how the background image repeats.', 'peony' ),
        'default'     => 'repeat',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $repeat
      );
  $options['peony_contact_background_position'] =  array(
        'id'          => 'peony_contact_background_position',
        'label'       => __( 'Background Position', 'peony' ),
        'description' => __( 'Set background image position.', 'peony' ),
        'default'     => 'top left',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $position
      );

  $options['peony_contact_title_color'] = array(
		'id' => 'peony_contact_title_color',
		'label'   => __( 'Title Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '',
		'description' => __( 'Set color for this section title.', 'peony' )
	);
	$options['peony_contact_content_color'] = array(
		'id' => 'peony_contact_content_color',
		'label'   => __( 'Content Color', 'peony' ),
		'section' => $section,
		'type'    => 'color',
		'default' => '',
		'description' => __( 'Set color for this section content.', 'peony' )
	);
	
	
	$options['peony_contact_title'] = array(
		'id' => 'peony_contact_title',
		'label' => __( 'Section Title', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'Contact',
	);
	
	$options['peony_contact_subtitle'] = array(
		'id' => 'peony_contact_subtitle',
		'label' => __( 'Subtitle', 'peony' ),
		'description' => '',
		'section' => $section,
		'type'    => 'text',
		'default' => '',
	);
	
	$options['peony_contact_id'] = array(
		'id' => 'peony_contact_id',
		'label' => __( 'Section ID', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'section-9',
	);

	$options['peony_contact_phone'] = array(
		'id' => 'peony_contact_phone',
		'label' => __( 'Phone', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => '595 12 34 567',
	);
	
	$options['peony_contact_email'] = array(
		'id' => 'peony_contact_email',
		'label' => __( 'Email', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => get_option( 'admin_email' ),
	);
 
	 $options['peony_contact_address'] = array(
		'id' => 'peony_contact_address',
		'label' => __( 'Address', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => '49 Costa Street, New Yoark City, USA',
	);
	 
	  $options['peony_contact_btn_text'] = array(
		'id' => 'peony_contact_btn_text',
		'label' => __( 'Button Text', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'SEND YOUR MESSAGE',
	);
	 
	 $options['peony_google_api_key'] = array(
		'id' => 'peony_google_api_key',
		'label' => __( 'Google API Key', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => '',
	);
	 
	 $options['peony_gmap_address'] = array(
		'id' => 'peony_gmap_address',
		'label' => __( 'Google Map Address', 'peony' ),
		'description'   => '',
		'section' => $section,
		'type'    => 'text',
		'default' => 'New York',
	);
	 
 ##### Styling #####
	
	// General
	$panel = 'styling';

	$panels[] = array(
		'id' => $panel,
		'title' => __( 'Styling', 'peony' ),
		'priority' => '2'
	);
		
		// Skin
    $section = 'general-styling';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'General', 'peony' ),
		'priority' => '11',
		'description' => '',
		'panel' => $panel
	);
    $options['peony_skin'] =  array(
        'id'          => 'peony_skin',
        'label'       => __( 'Skin', 'peony' ),
        'description' => '',
        'default'     => '0',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => array(0=>__( 'Light', 'peony' ),1=>__( 'Dark', 'peony' ))
      ); 
   
   //Background Colors

   $section = 'background_colors';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'Background Colors', 'peony' ),
		'priority' => '11',
		'description' => '',
		'panel' => $panel
	);


$options['peony_header_background_color'] = array(
        'id'          => 'peony_header_background_color',
        'label'      => __( 'Header Background Color', 'peony' ),
        'description'        => __( 'Set background color for header.', 'peony' ),
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
      );


$options['peony_menu_background_color'] = array(
        'id'          => 'peony_menu_background_color',
        'label'      => __( 'Menu Background Color', 'peony' ),
        'description'        => __( 'Header style 2 only.', 'peony' ),
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
      );
$options['peony_page_background_color'] =  array(
        'id'          => 'peony_page_background_color',
        'label'      => __( 'Page Background Color', 'peony' ),
        'description'        => __( 'Set background color for page.', 'peony' ),
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
                
      );

$options['peony_page_title_bar_background_color'] =  array(
        'id'          => 'peony_page_title_bar_background_color',
        'label'      => __( 'Page Title Bar Background Color', 'peony' ),
        'description'        => __( 'Set background color for page title bar.', 'peony' ),
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
      );

$options['peony_footer_background_color'] = array(
        'id'          => 'peony_footer_background_color',
        'label'      => __( 'Footer Background Color', 'peony' ),
        'description'        => __( 'Set background color for footer.', 'peony' ),
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
      );
$options['peony_copyright_background_color'] = array(
        'id'          => 'peony_copyright_background_color',
        'label'      => __( 'Copyright Area Background Color', 'peony' ),
        'description'        => __( 'Set background color for copyright area.', 'peony' ),
        'default'         => '#000000',
        'type'        => 'color',
        'section' => $section,
      );



   //Main Color

   $section = 'colors';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'Main Colors', 'peony' ),
		'priority' => '12',
		'description' => '',
		'panel' => $panel
	);
   
   $options['peony_copyright_color'] = array(
        'id'          => 'peony_copyright_color',
        'label'      => __( 'Footer Copyright Info Color', 'peony' ),
        'description'        => '',
        'default'         => '#ffffff',
        'type'        => 'color',
        'section' => $section,
      );
   

   $options['peony_btt_color'] = array(
        'id'          => 'peony_btt_color',
        'label'      => __( 'Back to Top Color', 'peony' ),
        'description'        => '',
        'default'         => '#ffffff',
        'type'        => 'color',
        'section' => $section,
      );
   $options['peony_page_title_color'] = array(
        'id'          => 'peony_page_title_color',
        'label'      => __( 'Page Title Color', 'peony' ),
        'description'        => '',
        'default'         => '#ffffff',
        'type'        => 'color',
        'section' => $section,
      );
   $options['peony_breadcrumb_text_color'] = array(
        'id'          => 'peony_breadcrumb_text_color',
        'label'      => __( 'Breadcrumb Text Color', 'peony' ),
        'description'        => '',
        'default'         => '#ffffff',
        'type'        => 'color',
        'section' => $section,
      );
   
    $options['peony_breadcrumb_link_color'] = array(
        'id'          => 'peony_breadcrumb_link_color',
        'label'      => __( 'Breadcrumb Link Color', 'peony' ),
        'description'        => '',
        'default'         => '#ffffff',
        'type'        => 'color',
        'section' => $section,
      );
   
    //Element Color

   $section = 'element_color';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'Element Colors', 'peony' ),
		'priority' => '13',
		'description' => '',
		'panel' => $panel
	);

   $options['peony_body_text_color'] = array(
        'id'          => 'peony_body_text_color',
        'label'      => __( 'Body Text Color', 'peony' ),
        'description'        => '',
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
      );
   
   $options['peony_body_link_color'] = array(
        'id'          => 'peony_body_link_color',
        'label'      => __( 'Body Link Color', 'peony' ),
        'description'        => '',
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
      );
   
   $options['peony_body_heading_color'] = array(
        'id'          => 'peony_body_heading_color',
        'label'      => __( 'Body Heading Color', 'peony' ),
        'description'        => '',
        'default'         => '#333333',
        'type'        => 'color',
        'section' => $section,
      );
   $options['peony_sidebar_widget_title_color'] = array(
        'id'          => 'peony_sidebar_widget_title_color',
        'label'      => __( 'Sidebar Widget title Color', 'peony' ),
        'description'        => '',
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
      );
   $options['peony_sidebar_widget_text_color'] = array(
        'id'          => 'peony_sidebar_widget_text_color',
        'label'      => __( 'Sidebar Widget text Color', 'peony' ),
        'description'        => '',
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
      );

   $options['peony_sidebar_link_color'] = array(
        'id'          => 'peony_sidebar_link_color',
        'label'      => __( 'Sidebar Link Color', 'peony' ),
        'description'        => '',
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
      );


    //Menu Color

   $section = 'menu_color';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'Menu Colors', 'peony' ),
		'priority' => '14',
		'description' => '',
		'panel' => $panel
	);

   $options['peony_menu_toggle_color'] = array(
        'id'          => 'peony_menu_toggle_color',
        'label'      => __( 'Menu Toggle Color', 'peony' ),
        'description'        => '',
        'default'         => '#ffffff',
        'type'        => 'color',
        'section' => $section,
      );
    $options['peony_menu_font_color'] = array(
        'id'          => 'peony_menu_font_color',
        'label'      => __( 'Menu Font Color', 'peony' ),
        'description'        => '',
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
      );
	 $options['peony_menu_hover_font_color'] = array(
        'id'          => 'peony_menu_hover_font_color',
        'label'      => __( 'Menu Hover Font Color', 'peony' ),
        'description'        => '',
        'default'         => '',
        'type'        => 'color',
        'section' => $section,
      );
   
		 
	 #### page title bar options ####
	
	$panel = 'page-title-bar';
	
		$panels[] = array(
			'id' => $panel,
			'title' => __( 'Page Title Bar', 'peony' ),
			'priority' => '5'
		);
	// Page Title Bar Options
	  $section = 'page-title-bar-general';
	  $sections[] = array(
		  'id' => $section,
		  'title' => __( 'General', 'peony' ),
		  'priority' => '10',
		  'description' => '',
		  'panel' => $panel
	  );
	$options['peony_enable_page_title_bar'] =  array(
			'id'          => 'peony_enable_page_title_bar',
			'label'       => __( 'Enable Page Title Bar', 'peony' ),
			'description' => '',
			'default'     => '1',
			'type'        => 'checkbox',
			'section'     => $section,
			'description' => __( 'Choose to display page title bar for pages & posts.', 'peony' )
		  );
	   
	$options['peony_page_title_bar_top_padding'] =  array(
			'id'          => 'peony_page_title_bar_top_padding',
			'label'      => __( 'Page Title Bar Top Padding', 'peony' ),
			'description'        => __( 'In pixels, ex: 210px', 'peony' ),
			'default'         => '210px',
			'type'        => 'text',
			'section' => $section,
			
		  );
	   
	$options['peony_page_title_bar_bottom_padding'] =  array(
			'id'          => 'peony_page_title_bar_bottom_padding',
			'label'      => __( 'Page Title Bar Bottom Padding', 'peony' ),
			'description'        => __( 'In pixels, ex: 160px', 'peony' ),
			'default'         => '160px',
			'type'        => 'text',
			'section' => $section,
			
		  );
	
	
	$options['peony_page_title_bar_background'] =  array(
			'id'          => 'peony_page_title_bar_background',
			'label'      => __( 'Page Title Bar Background', 'peony' ),
			'description'        => '',
			'default'         => '',
			'type'        => 'upload',
			'section' => $section,
			
		  );
	$options['peony_page_title_bar_bg_pos'] = array(
			'id'          => 'peony_page_title_bar_bg_pos',
			'label'      => __( 'Background Image Position', 'peony' ),
			'description'        => '',
			'default'         => 'top left',
			'type'        => 'select',
			'section' => $section,
			'choices'     => $position
		  );
		
	$options['peony_page_title_pos'] =  array(
			'id'          => 'peony_page_title_pos',
			'label'      => __( 'Page Title Position', 'peony' ),
			'description'        => __( 'Set alignment for page title.' ,'peony' ),
			'default'         => 'left',
			'type'        => 'select',
			'section' => $section,
			'choices'     => $align
		  );
	
	$options['peony_page_title_bg_full'] =  array(
			'id'          => 'peony_page_title_bg_full',
			'label'      => __( 'Background Full Width', 'peony' ),
			'description'        => '',
			'default'         => '1',
			'type'        => 'checkbox',
			'section' => $section,
		  );
	
	
	// Breadcrumb Options
	  $section = 'breadcrumb-options';
	  $sections[] = array(
		  'id' => $section,
		  'title' => __( 'Breadcrumb Options', 'peony' ),
		  'priority' => '11',
		  'description' => '',
		  'panel' => $panel
	  );
	 
	 $options['peony_display_breadcrumb'] =  array(
			'id'          => 'peony_display_breadcrumb',
			'label'       => __( 'Enable breadcrumb?', 'peony' ),
			'description' => __( 'Choose to display or hide breadcrumbs.', 'peony'),
			'default'     => '1',
			'type'        => 'checkbox',
			'section'     => $section,
		  );
	
	$options['peony_breadcrumb_menu_prefix'] =  array(
			'id'          => 'peony_breadcrumb_menu_prefix',
			'label'      => __( 'Breadcrumb Menu Prefix', 'peony' ),
			'description'        => __( 'The text before the breadcrumb menu.', 'peony' ),
			'default'         => '',
			'type'        => 'text',
			'section' => $section,
		  );
	$options['peony_breadcrumb_menu_separator'] =  array(
			'id'          => 'peony_breadcrumb_menu_separator',
			'label'      => __( 'Breadcrumb Menu Separator', 'peony' ),
			'description'        => __( 'Choose a separator between the single breadcrumbs.', 'peony' ),
			'default'         => '/',
			'type'        => 'text',
			'section' => $section,
	
		  );
	$options['peony_breadcrumb_show_post_type_archive'] =  array(
			'id'          => 'peony_breadcrumb_show_post_type_archive',
			'label'      => __( 'Show Custom Post Type Archives on Breadcrumbs.', 'peony' ),
			'description'        => __( 'Check to display custom post type archives in the breadcrumb path.', 'peony' ),
			'default'         => '1',
			'type'        => 'checkbox',
			'section' => $section,
		  );
	$options['peony_breadcrumb_show_categories'] =  array(
			'id'          => 'peony_breadcrumb_show_categories',
			'label'      => __( 'Show Post Categories on Breadcrumbs.', 'peony' ),
			'description'        => __( 'Check to display custom post type archives in the breadcrumb path.', 'peony' ),
			'default'         => '1',
			'type'        => 'checkbox',
			'section' => $section,        
	
		  );


	#### Footer options ####
	
	$panel = 'footer';
	
		$panels[] = array(
			'id' => $panel,
			'title' => __( 'Footer', 'peony' ),
			'priority' => '6'
		);
	// general
	  $section = 'footer-general';
	  $sections[] = array(
		  'id' => $section,
		  'title' => __( 'General', 'peony' ),
		  'priority' => '10',
		  'description' => '',
		  'panel' => $panel
	  );
	  
	  $options['peony_footer_top_padding'] =  array(
			'id'          => 'peony_footer_top_padding',
			'label'      => __( 'Top Padding', 'peony' ),
			'description'        => __( 'In pixels, ex: 60px', 'peony' ),
			'default'         => '60px',
			'type'        => 'text',
			'section' => $section,
			
		  );
	   
	$options['peony_footer_bottom_padding'] =  array(
			'id'          => 'peony_footer_bottom_padding',
			'label'      => __( 'Bottom Padding', 'peony' ),
			'description'        => __( 'In pixels, ex: 40px', 'peony' ),
			'default'         => '40px',
			'type'        => 'text',
			'section' => $section,
			
		  );

      $section = 'footer-copyright';
	  $sections[] = array(
		  'id' => $section,
		  'title' => __( 'Copyright', 'peony' ),
		  'priority' => '10',
		  'description' => '',
		  'panel' => $panel
	  );
	
	$options['peony_enable_tooltip'] =  array(
			'id'          => 'peony_enable_tooltip',
			'label'      => __( 'Enable Tooltip?', 'peony' ),
			'description'        => '',
			'default'         => '1',
			'type'        => 'checkbox',
			'section' => $section,
		  );
	

	$social_icon = array('fa-facebook','fa-instagram','fa-google-plus','fa-youtube','','','','');		
	$social_title = array('Facebook','Instagram','Google Plus','YouTube','','','','');	
	for( $i=1;$i<=8;$i++ ):

	$options['peony_footer_social_icon_'.$i] =  array(
			'id'          => 'peony_footer_social_icon_'.$i,
			'label'      => sprintf(__( 'Icon %d', 'peony' ),$i),
			'description'        => '',
			'default'         => $social_icon[$i-1],
			'type'        => 'text',
			'section' => $section,
		  );
	$options['peony_footer_social_title_'.$i] =  array(
			'id'          => 'peony_footer_social_title_'.$i,
			'label'      => sprintf(__( 'Title %d', 'peony' ),$i),
			'description'        => '',
			'default'         => $social_title[$i-1],
			'type'        => 'text',
			'section' => $section,
		  );
	$options['peony_footer_social_link_'.$i] =  array(
			'id'          => 'peony_footer_social_link_'.$i,
			'label'      => sprintf(__( 'Link %d', 'peony' ),$i),
			'description'        => '',
			'default'         => '#',
			'type'        => 'text',
			'section' => $section,
		  );
	   
	endfor;
	
	
	### Sidebar  ###
    $panel = 'sidebar';

	$panels[] = array(
		'id' => $panel,
		'title' => __( 'Sidebar', 'peony' ),
		'priority' => '7'
	);

 // Pages
	$section = 'sidebar-pages';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'Pages', 'peony' ),
		'priority' => '10',
		'description' => '',
		'panel' => $panel
	);

 
$options['peony_left_sidebar_pages'] =  array(
        'id'          => 'peony_left_sidebar_pages',
        'label'       => __( 'Left Sidebar', 'peony' ),
        'description' => __( 'Select left sidebar that will display on all pages.', 'peony' ),
        'default'     => '',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $peony_sidebars,
  
      );
$options['peony_right_sidebar_pages'] =  array(
        'id'          => 'peony_right_sidebar_pages',
        'label'       => __( 'Right Sidebar', 'peony' ),
        'description' => __( 'Select right sidebar that will display on all pages.', 'peony' ),
        'default'     => '',
        'type'        => 'select',
        'section'     => $section,
        'choices'     => $peony_sidebars,
  
      );

// Blog Posts
	$section = 'sidebar_blog_posts';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'Blog Posts', 'peony' ),
		'priority' => '11',
		'description' => '',
		'panel' => $panel
	);
 
$options['peony_left_sidebar_blog_posts'] =  array(
        'id'          => 'peony_left_sidebar_blog_posts',
        'label'      => __( 'Left Sidebar', 'peony' ),
        'description'        => __( 'Select left sidebar that will display on all blog posts.', 'peony' ),
        'default'         => '',
        'type'        => 'select',
        'section' => $section,
        
        
        'choices'     => $peony_sidebars,
	
      );
$options['peony_right_sidebar_blog_posts'] =  array(
        'id'          => 'peony_right_sidebar_blog_posts',
        'label'      => __( 'Right Sidebar', 'peony' ),
        'description'        => __( 'Select right sidebar that will display on all blog posts.', 'peony' ),
        'default'         => '',
        'type'        => 'select',
        'section' => $section,
        
        
        'choices'     => $peony_sidebars,
	
      );

// Blog Posts
	$section = 'sidebar_blog_archive';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'Blog Archive Category Pages', 'peony' ),
		'priority' => '12',
		'description' => '',
		'panel' => $panel
	);
 
$options['peony_left_sidebar_blog_archive'] =  array(
        'id'          => 'peony_left_sidebar_blog_archive',
        'label'      => __( 'Left Sidebar', 'peony' ),
        'description'        => __( 'Select left sidebar that will display on blog archive pages.', 'peony' ),
        'default'         => '',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $peony_sidebars,
	
      );
$options['peony_right_sidebar_blog_archive'] =  array(
        'id'          => 'peony_right_sidebar_blog_archive',
        'label'      => __( 'Right Sidebar', 'peony' ),
        'description'        => __( 'Select right sidebar that will display on blog archive pages.', 'peony' ),
        'default'         => '',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $peony_sidebars,
	
      );

//Sidebar search

  $section = 'sidebar_404';
  $sections[] = array(
	  'id' => $section,
	  'title' => __( '404 Page', 'peony' ),
	  'priority' => '15',
	  'description' => '',
	  'panel' => $panel
  );
 
$options['peony_left_sidebar_404'] =  array(
        'id'          => 'peony_left_sidebar_404',
        'label'      => __( 'Left Sidebar', 'peony' ),
        'description'        => __( 'Select left sidebar that will display on 404 pages.', 'peony' ),
        'default'         => '',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $peony_sidebars,
	
      );
$options['peony_right_sidebar_404'] =  array(
        'id'          => 'peony_right_sidebar_404',
        'label'      => __( 'Right Sidebar', 'peony' ),
        'description'        => __( 'Select right sidebar that will display on 404 pages.', 'peony' ),
        'default'         => '',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $peony_sidebars,
	
      );


### Typography ###
    $panel = 'typography';

	$panels[] = array(
		'id' => $panel,
		'title' => __( 'Typography', 'peony' ),
		'priority' => '8'
	);
	
 // Custom Google Fonts
  
  $section = 'load_google_fonts';
  $sections[] = array(
		'id' => $section,
		'title' => __( 'Load Google Fonts', 'peony' ),
		'priority' => '1',
		'description' => '',
		'panel' => $panel

	);
  
   $options['peony_google_fonts'] =  array(
        'id'          => 'peony_google_fonts',
        'label'       => __( 'Google Fonts ( e.g. Open+Sans:300,400,700|Lobster:400,700 )', 'peony' ) ,
        'description' => '',
        'default'     => 'Open+Sans:300,400,700|Lobster:400,700',
        'type'        => 'text',
        'section'     => $section,
        
      );
   
    //  Font Family
  
  $section = 'font_family';
  $sections[] = array(
		'id' => $section,
		'title' => __( 'Font Family', 'peony' ),
		'priority' => '2',
		'description' => '',
		'panel' => $panel

	);
   
   $options['peony_body_font'] =  array(
        'id'          => 'peony_body_font',
        'label'      => __( 'Select Body Font Family', 'peony' ),
        'description'        => __( 'Select a font family for body text.', 'peony' ),
        'default'         => '',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $default_theme_fonts_option
      );
	 
$options['peony_menu_font'] =  array(
        'id'          => 'peony_menu_font',
        'label'      => __( 'Select Menu Font Family', 'peony' ),
        'description'        => __( 'Select a font family for navigations.', 'peony' ),
        'default'         => '',
        'type'        => 'select',
        'section' => $section,
		'choices'     => $default_theme_fonts_option
      )
	;
$options['peony_headings_font'] = array(
        'id'          => 'peony_headings_font',
        'label'      => __( 'Select Headings Font Family', 'peony' ),
        'description'        => __( 'Select a font family for headings.', 'peony' ),
        'default'         => '',
        'type'        => 'select',
        'section' => $section,
        'condition'   => '',
        'choices'     => $default_theme_fonts_option
      );
$options['peony_section_title_font'] = array(
        'id'          => 'peony_section_title_font',
        'label'      => __( 'Select Sections Title Font Family', 'peony' ),
        'description'        => __( 'Select a font family for sections title.', 'peony' ),
        'default'         => '',
        'type'        => 'select',
        'section' => $section,
        'condition'   => '',
        'choices'     => $default_theme_fonts_option
      );
	
  
  // Font Size
	 
	$section = 'font_size';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'Font Size', 'peony' ),
		'priority' => '3',
		'description' => '',
		'panel' => $panel
	);
$options['peony_body_font_size'] =  array(
        'id'          => 'peony_body_font_size',
        'label'      => __( 'Body Font Size', 'peony' ),
        'description'        => '',
        'default'         => '14',
        'type'        => 'select',
        'section' => $section,
		'choices'     => $font_size
      );
 
$options['peony_main_menu_font_size'] =  array(
        'id'          => 'peony_main_menu_font_size',
        'label'      => __( 'Main Menu Font Size', 'peony' ),
        'description'        => '',
        'default'         => '14',
        'type'        => 'select',
        'section' => $section,
		'choices'     => $font_size
      );

$options['peony_secondary_menu_font_size'] =  array(
        'id'          => 'peony_secondary_menu_font_size',
        'label'      => __( 'Secondary Menu Font Size', 'peony' ),
        'description'        => '',
        'default'         => '14',
        'type'        => 'select',
        'section' => $section,
		'choices'     => $font_size
      );
$options['peony_sidebar_heading_font_size'] =  array(
        'id'          => 'peony_sidebar_heading_font_size',
        'label'      => __( 'Sidebar Widget Heading Font Size', 'peony' ),
        'description'        => '',
        'default'         => '16',
        'type'        => 'select',
        'section' => $section,
		'choices'     => $font_size
      );
$options['peony_sidebar_content_font_size'] =  array(
        'id'          => 'peony_sidebar_content_font_size',
        'label'      => __( 'Sidebar Widget Content Font Size', 'peony' ),
        'description'        => '',
        'default'         => '14',
        'type'        => 'select',
        'section' => $section,
		'choices'     => $font_size
      );

$options['peony_footer_widget_heading_font_size'] =  array(
        'id'          => 'peony_footer_widget_heading_font_size',
        'label'      => __( 'Footer Widget Heading Font Size', 'peony' ),
        'description'        => '',
        'default'         => '16',
        'type'        => 'select',
        'section' => $section,
		'choices'     => $font_size
      );


$options['peony_copyright_font_size'] =  array(
        'id'          => 'peony_copyright_font_size',
        'label'      => __( 'Copyright Font Size', 'peony' ),
        'description'        => '',
        'default'         => '12',
        'type'        => 'select',
        'section' => $section,
		'choices'     => $font_size
      );


$options['peony_h1_font_size'] =  array(
        'id'          => 'peony_h1_font_size',
        'label'      => __( 'Heading 1 (H1) Font Size', 'peony' ),
        'description'        => '',
        'default'         => '36',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
        
        
      );
$options['peony_h2_font_size'] =  array(
        'id'          => 'peony_h2_font_size',
        'label'      => __( 'Heading 2 (H2) Font Size', 'peony' ),
        'description'        => '',
        'default'         => '30',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
        
        
      );
$options['peony_h3_font_size'] =  array(
        'id'          => 'peony_h3_font_size',
        'label'      => __( 'Heading 3 (H3) Font Size', 'peony' ),
        'description'        => '',
        'default'         => '24',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
        
        
      );
$options['peony_h4_font_size'] =  array(
        'id'          => 'peony_h4_font_size',
        'label'      => __( 'Heading 4 (H4) Font Size', 'peony' ),
        'description'        => '',
        'default'         => '20',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
        
        
      );
$options['peony_h5_font_size'] =  array(
        'id'          => 'peony_h5_font_size',
        'label'      => __( 'Heading 5 (H5) Font Size', 'peony' ),
        'description'        => '',
        'default'         => '18',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
        
        
      );
$options['peony_h6_font_size'] =  array(
        'id'          => 'peony_h6_font_size',
        'label'      => __( 'Heading 6 (H6) Font Size', 'peony' ),
        'description'        => '',
        'default'         => '16',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
      );
$options['peony_site_name_font_size'] =  array(
        'id'          => 'peony_site_name_font_size',
        'label'      => __( 'Header Site Name Font Size', 'peony' ),
        'description'        => '',
        'default'         => '24',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
      );
$options['peony_tagline_font_size'] =  array(
        'id'          => 'peony_tagline_font_size',
        'label'      => __( 'Header Tagline Font Size', 'peony' ),
        'description'        => '',
        'default'         => '14',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
      );

$options['peony_sections_title_font_size'] =  array(
        'id'          => 'peony_sections_title_font_size',
        'label'      => __( 'Sections Title Font Size', 'peony' ),
        'description'        => '',
        'default'         => '36',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
      );


$options['peony_sections_content_font_size'] =  array(
        'id'          => 'peony_sections_content_font_size',
        'label'      => __( 'Sections Content Font Size', 'peony' ),
        'description'        => '',
        'default'         => '14',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
      );

$options['peony_page_title_font_size'] =  array(
        'id'          => 'peony_page_title_font_size',
        'label'      => __( 'Page Title Font Size', 'peony' ),
        'description'        => '',
        'default'         => '48',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
      );
$options['peony_breadcrumb_font_size'] =  array(
        'id'          => 'peony_breadcrumb_font_size',
        'label'      => __( 'Breadcrumb Font Size', 'peony' ),
        'description'        => '',
        'default'         => '14',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
      );
$options['peony_pagination_font_size'] =  array(
        'id'          => 'peony_pagination_font_size',
        'label'      => __( 'Pagination Font Size', 'peony' ),
        'description'        => '',
        'default'         => '14',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
      );
$options['peony_post_meta_font_size'] =  array(
        'id'          => 'peony_post_meta_font_size',
        'label'      => __( 'Post Meta Font Size', 'peony' ),
        'description'        => '',
        'default'         => '14',
        'type'        => 'select',
        'section' => $section,
        'choices'     => $font_size
      );

### Blog ###
    $panel = 'blog';

	$panels[] = array(
		'id' => $panel,
		'title' => __( 'Blog', 'peony' ),
		'priority' => '9'
	);
	// General Blog Options
    $section = 'general_blog_options';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'General', 'peony' ),
		'priority' => '10',
		'description' => '',
		'panel' => $panel
	);
 
 $options['peony_blog_style'] =  array(
        'id'          => 'peony_blog_style',
        'label'      => __( 'Blog List Style', 'peony' ),
        'description'        => '',
        'default'         => '1',
        'type'        => 'select',
        'section' => $section,
        'choices'     => array( '1' =>  __( 'List', 'peony' ),
								'2' =>  __( 'Grid', 'peony' ),
								),
      );	
 
$options['peony_blog_title'] =  array(
        'id'          => 'peony_blog_title',
        'label'      => __( 'Blog Page Title', 'peony' ),
        'description'        => __( 'This text will display in the page title bar of the assigned blog page.', 'peony' ),
        'default'         => 'Blog',
        'type'        => 'text',
        'section' => $section,    
      );

$options['peony_blog_subtitle'] =  array(
        'id'          => 'peony_blog_subtitle',
        'label'      => __( 'Blog Page Subtitle', 'peony' ),
        'description'        => __( 'This text will display in the page title bar of the assigned blog page.', 'peony' ),
        'default'         => 'Blog',
        'type'        => 'text',
        'section' => $section,    
      );

$options['peony_blog_pagination_type'] =  array(
        'id'          => 'peony_blog_pagination_type',
        'label'      => __( 'Pagination Type', 'peony' ),
        'description'        => __( 'Select the pagination type for the assigned blog page.', 'peony' ),
        'default'         =>  'pagination',
        'type'        => 'select',
        'section' => $section,
        'choices'     => array( 
          'pagination'     => __( 'Pagination', 'peony' ),
          'infinite_scroll'     => __( 'Infinite Scroll', 'peony' ),
        ),
	
      );
	
$options['peony_excerpt_or_content'] =  array(
        'id'          => 'peony_excerpt_or_content',
        'label'      => __( 'Excerpt or Full Blog Content', 'peony' ),
        'description'        => __( 'Choose to display an excerpt or full content on blog pages.', 'peony' ),
        'default'         => 'excerpt',
        'type'        => 'select',
        'section' => $section,
        'choices'     => array( 
          'excerpt'     => __( 'Excerpt', 'peony' ),
          'full_content'     => __( 'Full Content', 'peony' ), 
        ),
	
      );
$options['peony_excerpt_length'] =  array(
        'id'          => 'peony_excerpt_length',
        'label'      => __( 'Excerpt Length', 'peony' ),
        'description'        => __( 'Insert the number of words you want to show in the post excerpts.', 'peony' ),
        'default'         => '20',
        'type'        => 'text',
        'section' => $section,
      );

$options['peony_archive_display_image'] =  array(
        'id'          => 'peony_archive_display_image',
        'label'      => __( 'Show Featured Image?', 'peony' ),
        'description'        => __( 'Choose to display feature image in blog archive page.', 'peony' ),
        'default'         => '1',
        'type'        => 'checkbox',
        'section' => $section,
	
      );


// Blog Single Post Page Options
    $section = 'single_blog_options';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'Single Post Options', 'peony' ),
		'priority' => '11',
		'description' => '',
		'panel' => $panel
	);
 

$options['peony_single_display_title_bar'] =  array(
        'id'          => 'peony_single_display_title_bar',
        'label'      => __( 'Show Title Bar?', 'peony' ),
        'description'        => __( 'Choose to display page title bar in blog posts.', 'peony' ),
        'default'         => '1',
        'type'        => 'checkbox',
        'section' => $section,
	
      );

$options[ 'peony_single_display_image'] =  array(
        'id'          => 'peony_single_display_image',
        'label'      => __( 'Show Featured Image?', 'peony' ),
        'description'        => __( 'Choose to display feature image in blog posts.', 'peony' ),
        'default'         => '1',
        'type'        => 'checkbox',
        'section' => $section,
	
      );
$options['peony_display_pagination'] =  array(
        'id'          => 'peony_display_pagination',
        'label'      => __( 'Show Previous/Next Pagination?', 'peony' ),
        'description'        => __( 'Choose to display previous/next pagination in blog posts.', 'peony' ),
        'default'         => '1',
        'type'        => 'checkbox',
        'section' => $section,
	
      );
$options['peony_display_post_title'] =  array(
        'id'          => 'peony_display_post_title',
        'label'      => __( 'Show Post Title?', 'peony' ),
        'description'        => __( 'Choose to display post title in blog posts.', 'peony' ),
        'default'         => '1',
        'type'        => 'checkbox',
        'section' => $section,
	
      );
$options['peony_display_author_info_box'] =  array(
        'id'          => 'peony_display_author_info_box',
        'label'      => __( 'Show Author Info Box?', 'peony' ),
        'description'        => __( 'Choose to display author info box in blog posts.', 'peony' ),
        'default'         => '1',
        'type'        => 'checkbox',
        'section' => $section,
        'choices'     =>  $choices
	
      );

// Blog Meta Options
    $section = 'blog_meta_options';
	$sections[] = array(
		'id' => $section,
		'title' => __( 'Blog Meta Options', 'peony' ),
		'priority' => '11',
		'description' => '',
		'panel' => $panel
	);

$options['peony_display_post_meta'] =  array(
        'id'          => 'peony_display_post_meta',
        'label'      => __( 'Show Post Meta?', 'peony' ),
        'description'        => __( 'Choose to display post meta in blog posts.', 'peony' ),
        'default'         => '1',
        'type'        => 'checkbox',
        'section' => $section,
	
      );
$options['peony_display_meta_author'] =  array(
        'id'          => 'peony_display_meta_author',
        'label'      => __( 'Show Post Meta Author?', 'peony' ),
        'description'        => '',
        'default'         => '1',
        'type'        => 'checkbox',
        'section' => $section,
	
      );
$options['peony_display_meta_date'] =  array(
        'id'          => 'peony_display_meta_date',
        'label'      => __( 'Show Post Meta Date?', 'peony' ),
        'description'        => '',
        'default'         => '1',
        'type'        => 'checkbox',
        'section' => $section,
	
      );
$options['peony_display_meta_categories'] =  array(
        'id'          => 'peony_display_meta_categories',
        'label'      => __( 'Show Post Meta Categories?', 'peony' ),
        'description'        => '',
        'default'         => '1',
        'type'        => 'checkbox',
        'section' => $section,
      );

$options['peony_display_meta_comments'] =  array(
        'id'          => 'peony_display_meta_comments',
        'label'      => __( 'Show Post Meta Comments?', 'peony' ),
        'description'        => '',
        'default'         => '1',
        'type'        => 'checkbox',
        'section' => $section,
	
      );
$options['peony_display_meta_readmore'] =  array(
        'id'          => 'peony_display_meta_readmore',
        'label'      => __( 'Show Post Meta Read More?', 'peony' ),
        'description'        => '',
        'default'         => '',
        'type'        => 'checkbox',
        'section' => $section,
	
      );

### 404 Page  ###

$section = '404-page';
 $sections[] = array(
		'id' => $section,
		'title' => __( '404 Page', 'peony' ),
		'priority' => '10',
		'description' => '',
	);

$options['peony_title_404'] =  array(
        'id'          => 'peony_title_404',
        'label'       => __( '404 Page Title', 'peony' ),
        'description' => __( 'Insert title for 404 page.', 'peony' ),
        'default'     => 'OOPS!',
        'type'        => 'text',
        'section'     => $section,
        'choices'     =>  ''
	
      );

$options['peony_content_404'] =  array(
        'id'          => 'peony_content_404',
        'label'       => __( '404 Page Content', 'peony' ),
        'description' => __( 'Insert content for 404 page.', 'peony' ),
        'default'     => '<h1>OOPS!</h1><p>Can\'t find the page.</p>',
        'type'        => 'textarea',
        'section'     => $section,
        'choices'     =>  ''
	
      );

    $peony_default_options = array();
	foreach ( (array) $options as $option ) {
									  if ( ! isset( $option['id'] ) ) {
										  continue;
									  }
									  if ( ! isset( $option['default'] ) ) {
										  continue;
									  }
    $peony_default_options[$option['id']] = $option['default'];
	}


	// Adds the sections to the $options array
	$options['sections'] = $sections;

	// Adds the panels to the $options array
	$options['panels'] = $panels;

	$customizer_library = Customizer_Library::Instance();
	$customizer_library->add_options( $options );

	// To delete custom mods use: customizer_library_remove_theme_mods();

}
add_action( 'init', 'peony_customizer_options' );
