<?php
/**
 * The main template file.
 *
 * @package peony
 */

get_header(); 
$sidebar = 'none';
$left_sidebar              = esc_attr(peony_option('left_sidebar_blog_archive'));
$right_sidebar             = esc_attr(peony_option('right_sidebar_blog_archive'));
if( $left_sidebar !='' )
$sidebar ='left';
if( $right_sidebar !='' )
$sidebar ='right';
if( $left_sidebar !='' && $right_sidebar !='' )
$sidebar ='both';
$layout     = peony_option('layout');
$blog_pagination_type = peony_option('blog_pagination_type','pagination');
$container  = 'container';

$infinite_scroll = '';
if( $blog_pagination_type == 'infinite_scroll' )
$infinite_scroll = 'peony-infinite-scroll';
?>
<!--Main Area-->
        <section class="page-title-bar title-left no-subtitle peony_enable_page_title_bar">
            <div class="container">
                <hgroup class="page-title text-light">
                
                    <h1><?php single_cat_title('Currently browsing','peony'); ?> </h1>
                    <?php if(peony_option('blog_subtitle')):?>
                    <h3 class="peony_blog_subtitle"><?php echo esc_attr(peony_option('blog_subtitle'));?></h3>
                    <?php endif;?>
                </hgroup>
                    
                <div class="clearfix"></div>            
            </div>
        </section>

	   <div class="page-wrap">
            <div class="<?php echo $container;?>">
                <div class="page-inner row <?php echo peony_get_content_class($sidebar);?>">
                    <div class="col-main">
                        <section class="page-main" role="main" id="content">
                            <div class="page-content" id="<?php echo $infinite_scroll;?>">
                                <!--blog list begin-->
                                <?php
								 $list_wrap = '';
                                 $blog_style    = peony_option('blog_style');
								 $blog_template = 'article';
								 if( $blog_style == 2 ){
								 $list_wrap = 'blog-grid';
								 $blog_template = 'article-grid';
								 }
                                 ?>
                                <div class="blog-list-wrap <?php echo $list_wrap;?>" id="blog-list-wrap">

		    <?php if ( have_posts() ) : ?>

			<?php /* Start the Loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', $blog_template); ?>

			<?php endwhile; ?>


		<?php else : ?>

			<?php get_template_part( 'content', 'none' ); ?>

		<?php endif; ?>

		</div><!-- #blog-list-wrap -->
        
			<?php 
			//if( $blog_pagination_type == 'pagination' )
			peony_paging_nav('echo'); 
			
			?>
	  </div><!-- #page-content -->
       <div class="post-attributes"></div>
    </section><!-- #page-main -->
    </div><!-- #col-main -->
    
    <?php if( $sidebar == 'left' || $sidebar == 'both'  ): ?>
    <div class="col-aside-left" id="col-aside-left">
                        <aside class="blog-side left text-left">
                            <div class="widget-area">
                            <?php get_sidebar('archiveleft');?>
                            </div>
                        </aside>
                    </div>
            <?php endif; ?>
            <?php if( $sidebar == 'right' || $sidebar == 'both'  ): ?>        
                    <div class="col-aside-right" id="col-aside-right">
                        <div class="widget-area">
                           <?php get_sidebar('archiveright');?>
                            </div>
                    </div>
             <?php endif; ?>
                    <!-- #col-side -->
    </div><!-- #page-inner -->
    </div><!-- #container -->
    </div><!-- #page-wrap -->

<?php get_footer(); ?>