<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
 
<?php wp_head(); ?>
</head>
<?php
 global  $post;
			  
 $layout     = esc_attr(peony_option('layout'));
 $nav_menu   = 'primary';
 $wrapper    = '';
 $body_class = '';
 if( $layout == 'boxed' )
 $wrapper    = ' wrapper-boxed container ';
  
  $header_overlay = peony_option('header_overlay');
  $overlay = '';
  if( $header_overlay == '1')
  $overlay = 'overlay';
 
 $skin = peony_option('skin');
 if( $skin == '1' )
 $body_class    .= ' dark';
 
// dark
?>

<body <?php body_class($body_class); ?>>
    <div class="wrapper <?php echo $wrapper;?>">   
    <div class="top-wrap">
    <?php 
	  
	$custom_logo_id = get_theme_mod( 'custom_logo' );
	$image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
	$logo  =  $image[0];
						
	?>

<header id="header" class="logo-left <?php echo $overlay;?>">
					<div class="container">
						<div class="logo-box text-left">
							<a href="<?php echo esc_url(home_url('/')); ?>">
                            <?php if( $logo ):?>
                           <img class="site-logo normal_logo peony_standard_logo" alt="<?php bloginfo('name'); ?>" src="<?php echo esc_url($logo); ?>" >
                            <?php endif;?>
                            </a>
							<div class="name-box">
								<a href="<?php echo esc_url(home_url('/')); ?>"><h1 class="site-name"><?php bloginfo('name'); ?></h1></a>
								<span class="site-tagline"><?php bloginfo('description'); ?></span>
							</div>
						</div>
						<a class="site-nav-toggle">
							<span class="sr-only"><?php _e( 'Toggle navigation', 'peony' );?></span>
							<i class="fa fa-bars"></i>
						</a>
					</div>
					<nav class="site-nav">
						<h1 class="text-right"><?php bloginfo('name'); ?></h1>
						<button type="button" class="close" aria-label="<?php _e( 'Close', 'peony' );?>"><span aria-hidden="true">&times;</span></button>
						<?php
						 wp_nav_menu(array('theme_location'=>$nav_menu,'depth'=>0,'fallback_cb' =>false,'container'=>'','container_class'=>'main-menu','menu_id'=>'menu-main','menu_class'=>'main-nav','link_before' => '<span class="menu-item-label">', 'link_after' => '</span>','items_wrap'=> '<ul id="%1$s" class="%2$s">%3$s</ul>'));
						 ?>
					</nav>
				</header>
	</div>