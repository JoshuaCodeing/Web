<?php

/*
 * Loads the Options Panel
 *
 */
// Helper library for the theme customizer.
require get_template_directory() . '/inc/customizer-library/customizer-library.php';
// Define options for the theme customizer.
require get_template_directory() . '/inc/customizer-options.php';


/**
 * Set the content width based on the theme's design and stylesheet.
 */

if ( ! function_exists( 'peony_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function peony_setup() {
	global $content_width, $peony_options;
    $peony_options = get_theme_mods();
	
	if ( ! isset( $content_width ) ) {
		$content_width = str_replace('px','',peony_option('site_width',1170)); /* pixels */
	}
	
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on peony, use a find and replace
	 * to change '_s' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'peony' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'custom-logo' );
	add_editor_style("editor-style.css");
	add_image_size( 'peony-related-post', 400, 300, true ); //(cropped)
	add_theme_support( 'infinite-scroll', array(
		'type'           => 'scroll',
		'footer_widgets' => array( 'col-aside-right', 'col-aside-left' ),
		'container'      => 'peony-infinite-scroll',
		'wrapper'        => true,
		'render'         => false,
		'posts_per_page' => false,
		'footer' => false,
		
	) );
	
	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'peony' ),
	) );
	

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption',
	) );
	
	// Setup the WordPress core custom header feature.
	add_theme_support( 'custom-header', array(
        'default-image'          => '',
        'random-default'         => false,
        'width'                  => '1920',
        'height'                 => '120',
        'flex-height'            => true,
        'flex-width'             => true,
        'default-text-color'     => '',
        'header-text'            => true,
        'uploads'                => true,
        'wp-head-callback'       => '',
        'admin-head-callback'    => '',
        'admin-preview-callback' => ''
)); 

	// Setup the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'peony_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );


}
endif; // peony_setup
add_action( 'after_setup_theme', 'peony_setup' );

/**
 * get theme textdomain.
 */

function peony_get_textdomain(){
	
	$themename = get_option( 'stylesheet' );
	$themename = preg_replace("/\W/", "_", strtolower($themename) );
	return $themename;
	
	}

/**
 * get theme option.
 */

function peony_option( $name, $default = false ) {
	   global $peony_options,$peony_default_options;
	   
	   $name = 'peony_'.$name;
	   if( $default == false )
	   $default = isset($peony_default_options[$name])?$peony_default_options[$name]:$default;
	   
		if ( isset( $peony_options[$name] ) ) {
				return apply_filters( "theme_mod_{$name}", $peony_options[$name] );
		}

		if ( is_string( $default ) )
				$default = sprintf( $default, get_template_directory_uri(), get_stylesheet_directory_uri() );
		return apply_filters( "theme_mod_{$name}", $default );
}

add_action( 'widgets_init', 'peony_widgets' );
function peony_widgets(){
	global $peony_sidebars ;
	  $peony_sidebars =   array(
            ''  => __( 'No Sidebar', 'peony' ),
		    'default_sidebar'  => __( 'Default Sidebar', 'peony' ),
			'sidebar-1'  => __( 'Sidebar 1', 'peony' ),
			'sidebar-2'  => __( 'Sidebar 2', 'peony' ),
			'sidebar-3'  => __( 'Sidebar 3', 'peony' ),
			'sidebar-4'  => __( 'Sidebar 4', 'peony' ),
			'sidebar-5'  => __( 'Sidebar 5', 'peony' ),
			'sidebar-5'  => __( 'Sidebar 5', 'peony' ),
			'sidebar-6'  => __( 'Sidebar 6', 'peony' ),
			'footer_widget_1'  => __( 'Footer Widget 1', 'peony' ),
			'footer_widget_2'  => __( 'Footer Widget 2', 'peony' ),
			'footer_widget_3'  => __( 'Footer Widget 3', 'peony' ),
			'footer_widget_4'  => __( 'Footer Widget 4', 'peony' ),
			'left_sidebar_404'  => __( '404 Page Left Sidebar', 'peony' ),
			'right_sidebar_404'  => __( '404 Page Right Sidebar', 'peony' ),
          );
	  
	  foreach( $peony_sidebars as $k => $v ){
		  if( $k !='' ){
		  register_sidebar(array(
			'name' => $v,
			'id'   => $k,
			'before_widget' => '<div id="%1$s" class="widget widget-box %2$s">', 
			'after_widget' => '<span class="seperator extralight-border"></span></div>', 
			'before_title' => '<h2 class="widget-title">', 
			'after_title' => '</h2>' 
			));
		  }
		  }
		
}


/**
 * Enqueue scripts and styles.
 */

function peony_scripts() {

	global $peony_homepage_sections,$content_width,$post;
	
	$google_fonts = peony_option('google_fonts');
    if( trim($google_fonts) !='' ){
	$google_fonts = str_replace(' ','+',trim($google_fonts));
	wp_enqueue_style('peony-google-fonts', esc_url('//fonts.googleapis.com/css?family='.$google_fonts), false, '', false );
	}

	wp_enqueue_style( 'bootstrap',  get_template_directory_uri() .'/plugins/bootstrap/css/bootstrap.css', false, '', false );
	wp_enqueue_style( 'font-awesome',  get_template_directory_uri() .'/plugins/font-awesome/css/font-awesome.min.css', false, '', false );
	wp_enqueue_style( 'jquery.fullPage',  get_template_directory_uri() .'/plugins/jquery-fullPage/jquery.fullPage.css', false, '', false );
	wp_enqueue_style( 'owl.carousel',  get_template_directory_uri() .'/plugins/owl-carousel/assets/owl.carousel.css', false, '', false );
	wp_enqueue_style( 'owl.theme.default',  get_template_directory_uri() .'/plugins/owl-carousel/assets/owl.theme.default.css', false, '', false );
	wp_enqueue_style( 'prettyPhoto',  get_template_directory_uri() .'/plugins/jquery-prettyPhoto/prettyPhoto.css', false, '', false );
	wp_enqueue_style( 'peony-bbpress',  get_template_directory_uri() .'/css/bbpress.css', false, '', false );
    wp_enqueue_style( 'peony-style', get_stylesheet_uri() );
	
    wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/plugins/bootstrap/js/bootstrap.js' , array( 'jquery' ), null, true);
    wp_enqueue_script('masonry');
	wp_enqueue_script( 'jquery.fullPage', get_template_directory_uri() . '/plugins/jquery-fullPage/jquery.fullPage.min.js' , array( 'jquery' ), null, true);
	wp_enqueue_script( 'owl.carousel', get_template_directory_uri() . '/plugins/owl-carousel/owl.carousel.js' , array( 'jquery' ), null, true);
	
	wp_enqueue_script( 'jquery.prettyPhoto', get_template_directory_uri() . '/plugins/jquery-prettyPhoto/jquery.prettyPhoto.js' , array( 'jquery' ), null, true);
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	
	$section_contact_hide = peony_option('section_contact_hide');
	if( $section_contact_hide != '1' ){
	$google_api_key = esc_attr(peony_option('google_api_key'));
	wp_enqueue_script( 'peony-google-map-api', esc_url('//maps.google.com/maps/api/js?key='.$google_api_key), array( 'jquery' ), null, true );
	}
	
	wp_enqueue_script( 'jquery.infinitescroll', get_template_directory_uri() . '/plugins/jquery.infinitescroll.js', 'jquery', null, true );
	wp_enqueue_script( 'respond', get_template_directory_uri() . '/plugins/respond.min.js', 'jquery', null, true );
	wp_enqueue_script( 'peony-main', get_template_directory_uri() . '/js/main.js', array( 'jquery' ), null, true );
	
	//## home page sections
	$i = 0;
	$custom_css       = '';
	$peony_custom_css = '';
	$anchors          = array();
	$navigationTooltips = array();
	foreach( $peony_homepage_sections as $k=>$v ){
		
		$section_id    = peony_option( $k.'_id');
		$section_id    = $section_id ==''? 'section-'.$k:$section_id ;
		$section_title = peony_option( $k.'_title');
		$section_title = $section_title == ''? '':$section_title;
		
		$background_color = peony_option( $k.'_background_color');
		$background_image = peony_option( $k.'_background_image');
		$background_repeat =  peony_option( $k.'_background_repeat');
		$background_position =  peony_option( $k.'_background_position');
		$title_color = peony_option( $k.'_title_color');
		$content_color = peony_option( $k.'_content_color');
		
		$peony_custom_css .="section.section-".$k."{\r\n";
		$peony_custom_css .="background-color:".esc_attr($background_color).";\r\n";
		$peony_custom_css .="background-image:url(".esc_url($background_image).");\r\n";
		$peony_custom_css .="background-repeat:".esc_attr($background_repeat).";\r\n";
		$peony_custom_css .="background-position:".esc_attr($background_position).";\r\n";
		$peony_custom_css .="}\r\n";
		$peony_custom_css .="section.section-".$k." .section-title{\r\n";
		$peony_custom_css .="color:".esc_attr($title_color).";\r\n";
		$peony_custom_css .="}\r\n";
		$peony_custom_css .="section.section-".$k." .section-content,section.section-".$k." .section-subtitle{\r\n";
		$peony_custom_css .="color:".esc_attr($content_color).";\r\n";
		$peony_custom_css .="}\r\n";
		$anchors[]         = $section_id;
		$navigationTooltips[]  = $section_title;
		$i++;
		}
	
	$header_background_image     = get_header_image();
	$header_background_position  = peony_option('header_bg_pos');
	
	
	$header_background       = '';
	if( $header_background_image ){
		$header_background  .= "header#header{\r\n";
	    $header_background  .= "background-image: url(".esc_url($header_background_image).");\r\n";	
	    $header_background  .=  "background-position:".esc_attr($header_background_position).";";
        $header_background  .= "}\r\n";	
	}
	
	
	$peony_custom_css .= $header_background;
	$header_text_color = get_header_textcolor();
	
	if ( 'blank' != $header_text_color ) :
	
	$peony_custom_css .= ".site-name,
		.site-tagline {
			color: #".esc_attr( $header_text_color )." !important;
		}";
	
	endif;
	
	// Background Colors
	
	$header_background_color = peony_option('header_background_color');
	$menu_background_color = peony_option('menu_background_color');
	$page_background_color = peony_option('page_background_color');
	$page_title_bar_background_color = peony_option('page_title_bar_background_color');
	$footer_background_color = peony_option('footer_background_color');
	$copyright_background_color = peony_option('copyright_background_color');
	
	$peony_custom_css .= "header#header{\r\n";
	$peony_custom_css  .=  "background-color:".esc_attr($header_background_color).";";
	$peony_custom_css .= "}\r\n";
	
	$peony_custom_css .= "header#header .site-nav{\r\n";
	$peony_custom_css  .=  "background-color:".esc_attr($menu_background_color).";";
	$peony_custom_css .= "}\r\n";
	
	$peony_custom_css .= ".post-wrap{\r\n";
	$peony_custom_css  .=  "background-color:".esc_attr($page_background_color).";";
	$peony_custom_css .= "}\r\n";
	
	$peony_custom_css .= ".page-title-bar{\r\n";
	$peony_custom_css  .=  "background-color:".esc_attr($page_title_bar_background_color).";";
	$peony_custom_css .= "}\r\n";
	
	$peony_custom_css .= ".footer-widget-area{\r\n";
	$peony_custom_css  .=  "background-color:".esc_attr($footer_background_color).";";
	$peony_custom_css .= "}\r\n";
	
	$peony_custom_css .= ".footer-info-area{\r\n";
	$peony_custom_css  .=  "background-color:".esc_attr($copyright_background_color).";";
	$peony_custom_css .= "}\r\n";
	
	
	//Main Color

	$copyright_color       = peony_option('copyright_color');
	$footer_social_color   = peony_option('footer_social_color');
	$btt_color             = peony_option('btt_color');
	$page_title_color      = peony_option('page_title_color');
	$breadcrumb_text_color = peony_option('breadcrumb_text_color');
	$breadcrumb_link_color = peony_option('breadcrumb_link_color');
	
	
	$peony_custom_css .= ".footer-info-area,.footer-info-area p,.footer-info-area a{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($copyright_color).";";
	$peony_custom_css .= "}\r\n";
	
	$btt_color_rgb     = peony_hex2rgb($btt_color );
	$peony_custom_css .= ".scroll-to-top {\r\n";
	$peony_custom_css .=  "background-color: rgba(".absint($btt_color_rgb[0]).",".absint($btt_color_rgb[1]).",".absint($btt_color_rgb[2]).",.2);";
	$peony_custom_css .= "}\r\n";
	
	if( $page_title_color != '' ){
	$peony_custom_css .= "body .page-title,body .page-title h1{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($page_title_color).";";
	$peony_custom_css .= "}\r\n";
	}
	
	$peony_custom_css .= ".breadcrumb-nav ,.breadcrumb-nav span{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($breadcrumb_text_color).";";
	$peony_custom_css .= "}\r\n";
	
	$peony_custom_css .= ".breadcrumb-nav a{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($breadcrumb_link_color).";";
	$peony_custom_css .= "}\r\n";
	

	 //Element Color
	$body_text_color  = peony_option('body_text_color');
	$body_link_color  = peony_option('body_link_color');
	$body_heading_color = peony_option('body_heading_color');
	$sidebar_widget_title_color = peony_option('sidebar_widget_title_color');
	$sidebar_widget_text_color = peony_option('sidebar_widget_text_color');
	$sidebar_link_color = peony_option('sidebar_link_color');

    $peony_custom_css .= ".entry-content,entry-content p,entry-content span{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($body_text_color).";";
	$peony_custom_css .= "}\r\n";
	
	$peony_custom_css .= ".entry-content a{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($body_link_color).";";
	$peony_custom_css .= "}\r\n";
	
	if( $body_heading_color != '' ){
	$peony_custom_css .= "body .entry-content h1,
	body .entry-content h2,
	body .entry-content h3,
	body .entry-content h4,
	body .entry-content h5{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($body_heading_color)." ;";
	$peony_custom_css .= "}\r\n";
	}
	
	if( $sidebar_widget_title_color != '' ){
	$peony_custom_css .= ".col-aside-right .widget-title,.col-aside-left .widget-title{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($sidebar_widget_title_color)." !important;";
	$peony_custom_css .= "}\r\n";
	}
	
	if( $sidebar_widget_text_color != '' ){
	$peony_custom_css .= ".col-aside-right  .widget-box,
	                      .col-aside-right .widget-box span,
						  .col-aside-left  .widget-box,
	                      .col-aside-left .widget-box span{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($sidebar_widget_text_color)." !important;";
	$peony_custom_css .= "}\r\n";
	}
	
	if( $sidebar_link_color != '' ){
	$peony_custom_css .= ".col-aside-right .widget-box a,.col-aside-left .widget-box a{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($sidebar_link_color)." !important;";
	$peony_custom_css .= "}\r\n";
	}
	
    //Menu Color
    $menu_toggle_color     = peony_option('menu_toggle_color');
	$menu_font_color       = peony_option('menu_font_color');
	$menu_hover_font_color = peony_option('menu_hover_font_color');

	if( $menu_toggle_color != '' ){
	$peony_custom_css .= ".site-nav-toggle i{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($menu_toggle_color).";";
	$peony_custom_css .= "}\r\n";
	$peony_custom_css .= "a.site-nav-toggle{\r\n";
	$peony_custom_css  .=  "border: 1px solid ".esc_attr($menu_toggle_color).";";
	$peony_custom_css .= "}\r\n";
	}
	
	
	$peony_custom_css .= ".site-nav li a span,.site-nav li a{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($menu_font_color).";";
	$peony_custom_css .= "}\r\n";
	
	$peony_custom_css .= ".site-nav li a span:hover,.site-nav li a:hover{\r\n";
	$peony_custom_css  .=  "color:".esc_attr($menu_hover_font_color).";";
	$peony_custom_css .= "}\r\n";
	
	
	// page title bar

	$page_title_bar_top_padding           = esc_attr(peony_option('page_title_bar_top_padding'));
	$page_title_bar_bottom_padding        = esc_attr(peony_option('page_title_bar_bottom_padding'));
	$page_title_bar_background_img        = esc_url(peony_option('page_title_bar_background'));
	$page_title_bar_bg_pos                = esc_attr(peony_option('page_title_bar_bg_pos'));
	$page_title_bg_full                   = esc_attr(peony_option('page_title_bg_full'));

	
	
	$page_title_bar_background  = '';
	if( $page_title_bar_background_img ){
		$page_title_bar_background  .= ".page-title-bar{\r\n";
		
	    $page_title_bar_background  .= "background-image: url(".$page_title_bar_background_img.");\r\n";
		if( $page_title_bg_full == '1' )
		$page_title_bar_background  .= "-webkit-background-size: cover;
								-moz-background-size: cover;
								-o-background-size: cover;
								background-size: cover;\r\n";
								
		if( $page_title_bar_bg_pos != '' )
		$page_title_bar_background  .= "background-position:".$page_title_bar_bg_pos.";";
								
        $page_title_bar_background  .= "}\r\n";	
	}
	
	$peony_custom_css .= ".page-title-bar{
		padding-top:".$page_title_bar_top_padding .";
		padding-bottom:".$page_title_bar_bottom_padding .";
		}";
	
	$peony_custom_css .=  $page_title_bar_background ;
	
	// footer
	$footer_top_padding           = esc_attr(peony_option('footer_top_padding'));
	$footer_bottom_padding        = esc_attr(peony_option('footer_bottom_padding'));
	
	$peony_custom_css .= ".footer-widget-area{
		padding-top:".$footer_top_padding .";
		padding-bottom:".$footer_bottom_padding .";
		}";
		
		
	//  Font Family
	
	$body_font          = str_replace('&#039;','\'', esc_attr(peony_option('body_font')));
	$menu_font          = str_replace('&#039;','\'', esc_attr(peony_option('menu_font')));
	$headings_font      = str_replace('&#039;','\'', esc_attr(peony_option('headings_font')));
	$section_title_font = str_replace('&#039;','\'', esc_attr(peony_option('section_title_font')));
	
	if( $body_font ){
	$peony_custom_css  .= "body{
		font-family:".$body_font.";
		}\r\n";
	}
	if( $menu_font ){
	$peony_custom_css  .= ".site-nav a,.site-nav span{
		font-family:".$menu_font.";
		}\r\n";
	}
	if( $menu_font ){
	$peony_custom_css  .= "h1,h2,h3,h4,h5,h6{
		font-family:".$headings_font.";
		}\r\n";
	}
	if( $section_title_font ){
	$peony_custom_css  .= ".section-title{
		font-family:".$section_title_font.";
		}\r\n";
	}
	
	// Font size
	
   $body_font_size                  = absint(peony_option('body_font_size'));
   $main_menu_font_size             = absint(peony_option('main_menu_font_size'));
   $secondary_menu_font_size        = absint(peony_option('secondary_menu_font_size'));
   $breadcrumb_font_size            = absint(peony_option('breadcrumb_font_size'));
   $sidebar_heading_font_size = absint(peony_option('sidebar_heading_font_size'));
   $footer_widget_heading_font_size = absint(peony_option('footer_widget_heading_font_size'));
   
   $h1_font_size   = absint(peony_option('h1_font_size'));
   $h2_font_size   = absint(peony_option('h2_font_size'));
   $h3_font_size   = absint(peony_option('h3_font_size'));
   $h4_font_size   = absint(peony_option('h4_font_size'));
   $h5_font_size   = absint(peony_option('h5_font_size'));
   $h6_font_size   = absint(peony_option('h6_font_size'));
   
   $tagline_font_size    = absint(peony_option('h6_font_size'));
   $meta_data_font_size  = absint(peony_option('meta_data_font_size'));
   $page_title_font_size = absint(peony_option('page_title_font_size'));
   $page_title_subheader_font_size    = absint(peony_option('page_title_subheader_font_size'));
   $pagination_font_size    = absint(peony_option('pagination_font_size'));
   $woocommerce_icon_font_size    = absint(peony_option('woocommerce_icon_font_size'));
   
   
    $peony_custom_css  .= "body{ font-size:". $body_font_size ."px}";
	$peony_custom_css  .= "#menu-main > li > a > span{ font-size:". $main_menu_font_size ."px}";
	$peony_custom_css  .= "#menu-main li li a span{ font-size:". $secondary_menu_font_size ."px}";
	$peony_custom_css  .= ".breadcrumb-nav span,.breadcrumb-nav a{ font-size:". $breadcrumb_font_size ."px}";
	$peony_custom_css  .= ".post-wrap .widget-area .widget-title{ font-size:". $sidebar_heading_font_size ."px}";
	$peony_custom_css  .= ".footer-widget-area .widget-title{ font-size:". $footer_widget_heading_font_size ."px}";
	
	$peony_custom_css  .= "h1{ font-size:". $h1_font_size ."px}";
	$peony_custom_css  .= "h2{ font-size:". $h2_font_size ."px}";
	$peony_custom_css  .= "h3{ font-size:". $h3_font_size ."px}";
	$peony_custom_css  .= "h4{ font-size:". $h4_font_size ."px}";
	$peony_custom_css  .= "h5{ font-size:". $h5_font_size ."px}";
	$peony_custom_css  .= "h6{ font-size:". $h6_font_size ."px}";
	
	$peony_custom_css  .= ".site-tagline{ font-size:". $tagline_font_size ."px}";
	$peony_custom_css  .= ".page-title h1{ font-size:". $page_title_font_size ."px}";
	$peony_custom_css  .= ".page-title h3{ font-size:". $page_title_subheader_font_size ."px}";
	$peony_custom_css  .= ".post-pagination li a{ font-size:". $pagination_font_size ."px}";

	wp_add_inline_style( 'peony-style', $peony_custom_css );
	
	$blog_carousel_col = 3;
	$scheme = peony_option('scheme');

	$blog_pagination_type = esc_attr(peony_option('blog_pagination_type','pagination'));
	$gmap_address         = esc_attr(peony_option('gmap_address'));
	
	wp_localize_script( 'peony-main', 'peony_params', array(
			'ajaxurl'        => admin_url('admin-ajax.php'),
			'themeurl' => get_template_directory_uri(),
			'anchors' => json_encode($anchors),
			'navigationTooltips' =>  json_encode($navigationTooltips),
			'blog_carousel_col' => $blog_carousel_col,
			'blog_pagination_type' => $blog_pagination_type,
			'gmap_address' => $gmap_address,
		)  );

}
add_action( 'wp_enqueue_scripts', 'peony_scripts' );


// Convert Hex Code to RGB

function peony_hex2rgb( $hex ) {
		if ( strpos( $hex,'rgb' ) !== FALSE ) {

			$rgb_part = strstr( $hex, '(' );
			$rgb_part = trim($rgb_part, '(' );
			$rgb_part = rtrim($rgb_part, ')' );
			$rgb_part = explode( ',', $rgb_part );

			$rgb = array($rgb_part[0], $rgb_part[1], $rgb_part[2], $rgb_part[3]);

		} elseif( $hex == 'transparent' ) {
			$rgb = array( '255', '255', '255', '0' );
		} else {

			$hex = str_replace( '#', '', $hex );

			if( strlen( $hex ) == 3 ) {
				$r = hexdec( substr( $hex, 0, 1 ) . substr( $hex, 0, 1 ) );
				$g = hexdec( substr( $hex, 1, 1 ) . substr( $hex, 1, 1 ) );
				$b = hexdec( substr( $hex, 2, 1 ) . substr( $hex, 2, 1 ) );
			} else {
				$r = hexdec( substr( $hex, 0, 2 ) );
				$g = hexdec( substr( $hex, 2, 2 ) );
				$b = hexdec( substr( $hex, 4, 2 ) );
			}
			$rgb = array( $r, $g, $b );
		}

		return $rgb; 
	}
	
 // get summary

 function peony_get_summary(){
	 
	 $excerpt_or_content = peony_option('excerpt_or_content');
	 
	 if( $excerpt_or_content == 'full_content' ){
	 $output = get_the_content();
	 }
	 else{
	 $output = get_the_excerpt();
	 }
	 return  $output;
	 }
	 
// excerpt length
 function peony_excerpt_length( $length ) {
	   
	   $excerpt_length = absint(peony_option('excerpt_length'));
	   if( $excerpt_length > 0 )
	   return $excerpt_length;
  }
  add_filter( 'excerpt_length', 'peony_excerpt_length', 999 );
 
  // get breadcrumbs
 function peony_get_breadcrumb( $options = array()){
   global $post,$wp_query ;
    $postid = isset($post->ID)?$post->ID:"";
	
   $show_breadcrumb = "";
   if ( 'page' == get_option( 'show_on_front' ) && ( '' != get_option( 'page_for_posts' ) ) && $wp_query->get_queried_object_id() == get_option( 'page_for_posts' ) ) { 
    $postid = $wp_query->get_queried_object_id();
   }
  
   if(isset($postid) && is_numeric($postid)){
    $show_breadcrumb = get_post_meta( $postid, '_peony_show_breadcrumb', true );
	}
	if($show_breadcrumb == 'yes' || $show_breadcrumb==""){

               peony_breadcrumb( $options);           
	}
	   
	}
	
	
	// get post content css class
 function peony_get_content_class( $sidebar = '' ){
	 
	 if( $sidebar == 'left' )
	 return 'left-aside';
	 if( $sidebar == 'right' )
	 return 'right-aside';
	 if( $sidebar == 'both' )
	 return 'both-aside';
	  if( $sidebar == 'none' )
	 return 'no-aside';
	 
	 return 'no-aside';
	 
	 }
	 
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function peony_posted_on( $echo = true ) {
	$return = '';
	$display_post_meta = peony_option('display_post_meta');
		
	if( $display_post_meta == '1' ){
		
	  $display_meta_author     = peony_option('display_meta_author');
	  $display_meta_date       = peony_option('display_meta_date');
	  $display_meta_categories = peony_option('display_meta_categories');
	  $display_meta_comments   = peony_option('display_meta_comments');
	  $display_meta_readmore   = peony_option('display_meta_readmore');
	  $display_meta_tags       = peony_option('display_meta_tags');
	
	   $return .=  '<ul class="entry-meta">';
	  if( $display_meta_date == '1' )
		$return .=  '<li class="entry-date"><i class="fa fa-calendar"></i>'. get_the_date(  ).'</li>';
	  if( $display_meta_author == '1' )
		$return .=  '<li class="entry-author"><i class="fa fa-user"></i>'.get_the_author_link().'</li>';
	  if( $display_meta_categories == '1' )		
		$return .=  '<li class="entry-catagory"><i class="fa fa-file-o"></i>'.get_the_category_list(', ').'</li>';
	  if( $display_meta_comments == '1' )	
		$return .=  '<li class="entry-comments pull-right">'.peony_get_comments_popup_link('', __( '<i class="fa fa-comment"></i> 1 ', 'peony'), __( '<i class="fa fa-comment"></i> % ', 'peony'), 'read-comments', '').'</li>';
        $return .=  '</ul>';
	}

	 if( $echo == true )
	echo $return;
	else
	return $return;

}

/**
 * Modifies WordPress's built-in comments_popup_link() function to return a string instead of echo comment results
 */
function peony_get_comments_popup_link( $zero = false, $one = false, $more = false, $peony_css_class = '', $none = false ) {
    global $wpcommentspopupfile, $wpcommentsjavascript;
 
    $id = get_the_ID();
 
    if ( false === $zero ) $zero = __( 'No Comments', 'peony');
    if ( false === $one ) $one = __( '1 Comment', 'peony');
    if ( false === $more ) $more = __( '% Comments', 'peony');
    if ( false === $none ) $none = __( 'Comments Off', 'peony');
 
    $number = get_comments_number( $id );
 
    $str = '';
 
    if ( 0 == $number && !comments_open() && !pings_open() ) {
        $str = '<span' . ((!empty($peony_css_class)) ? ' class="' . esc_attr( $peony_css_class ) . '"' : '') . '>' . $none . '</span>';
        return $str;
    }
	
 
    if ( post_password_required() ) {
     
        return '';
    }
 
    $str = '<a href="';
    if ( $wpcommentsjavascript ) {
        if ( empty( $wpcommentspopupfile ) )
            $home = home_url();
        else
            $home = get_option('siteurl');
        $str .= $home . '/' . $wpcommentspopupfile . '?comments_popup=' . $id;
        $str .= '" onclick="wpopen(this.href); return false"';
    } else { // if comments_popup_script() is not in the template, display simple comment link
        if ( 0 == $number )
            $str .= get_permalink() . '#respond';
        else
            $str .= get_comments_link();
        $str .= '"';
    }
 
    if ( !empty( $peony_css_class ) ) {
        $str .= ' class="'.$peony_css_class.'" ';
    }
    $title = the_title_attribute( array('echo' => 0 ) );
 
    $str .= apply_filters( 'comments_popup_link_attributes', '' );
 
    $str .= ' title="' . esc_attr( sprintf( __('Comment on %s', 'peony'), $title ) ) . '">';
    $str .= peony_get_comments_number_str( $zero, $one, $more );
    $str .= '</a>';
     
    return $str;
}

/**
 * Modifies WordPress's built-in comments_number() function to return string instead of echo
 */
function peony_get_comments_number_str( $zero = false, $one = false, $more = false, $deprecated = '' ) {
    if ( !empty( $deprecated ) )
        _deprecated_argument( __FUNCTION__, '1.3' );
 
    $number = get_comments_number();
 
    if ( $number > 1 )
        $output = str_replace('%', number_format_i18n($number), ( false === $more ) ? __('% Comments', 'peony') : $more);
    elseif ( $number == 0 )
        $output = ( false === $zero ) ? __('No Comments', 'peony') : $zero;
    else // must be one
        $output = ( false === $one ) ? __('1 Comment', 'peony') : $one;
 
    return apply_filters('comments_number', $output, $number);
}

/**
 * Display navigation to next/previous set of posts when applicable.
 */
function peony_paging_nav($echo='echo',$wp_query='') {
    if(!$wp_query){global $wp_query;}
    global $wp_rewrite;      
    $wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;

	$pagination = array(
	'base' => @add_query_arg('paged','%#%'),
	'format'             => '?page=%#%',
	'total'              => $wp_query->max_num_pages,
	'current'            => $current,
	'show_all'           => false,
	'end_size'           => 1,
	'mid_size'           => 2,
	'prev_next'          => true,
	'prev_text'          => __(' Prev', 'peony'),
	'next_text'          => __('Next ', 'peony'),
	'type'               => 'list',
	'add_args'           => false,
	'add_fragment'       => '',
	'before_page_number' => '',
	'after_page_number'  => ''
);
 
    if( $wp_rewrite->using_permalinks() )
        $pagination['base'] = user_trailingslashit( trailingslashit( remove_query_arg('s',get_pagenum_link(1) ) ) . 'page/%#%/', 'paged');
 
    if( !empty($wp_query->query_vars['s']) )
        $pagination['add_args'] = array('s'=>get_query_var('s'));
		
	if( $wp_query->max_num_pages > 1 ){
    if($echo == "echo"){
    echo '<nav class="post-pagination post-list-pagination" role="navigation">
                                    <div class="post-pagination-decoration"></div>
                                    '.paginate_links($pagination).'</nav>'; 
	}else
	{
	
	return '<nav class="post-pagination post-list-pagination" role="navigation">
                                    <div class="post-pagination-decoration"></div>'.paginate_links($pagination).'</nav>';
	}
	}
}

	// get related posts
	
 function peony_get_related_posts($post_id, $number_posts = -1,$post_type = 'post') {
	$query = new WP_Query();

    $args = '';

	if($number_posts == 0) {
		return $query;
	}

	$args = wp_parse_args($args, array(
		'posts_per_page' => $number_posts,
		'post__not_in' => array($post_id),
		'ignore_sticky_posts' => 0,
        'meta_key' => '_thumbnail_id',
        'category__in' => wp_get_post_categories($post_id),
		'post_type' =>$post_type 
	));

	$query = new WP_Query($args);

  	return $query;
}

// Custom comments list
   
function peony_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; 

   ?>
   
<li <?php comment_class("comment media-comment"); ?> id="comment-<?php comment_ID() ;?>">
                                                <div class="media-avatar media-left">
                                                   <?php echo get_avatar($comment,'70','' ); ?>
                                                </div>
                                                <div class="media-body">
                                                    <div class="media-inner">
                                                        <h4 class="media-heading clearfix">
                                                           <?php echo get_comment_author_link();?> - <?php comment_date(); ?> <?php edit_comment_link(__('(Edit)','peony'),'  ','') ;?>
                                                           <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ;?>
                                                        </h4>
                                                        
                                                        <?php if ($comment->comment_approved == '0') : ?>
                                                                 <em><?php _e('Your comment is awaiting moderation.','peony') ;?></em>
                                                                 <br />
                                                              <?php endif; ?>
                                                              
                                                        <div class="comment-content"><?php comment_text() ;?></div>
                                                    </div>
                                                </div>
                                            </li>
                                            
<?php
        }
		
		  
/**
 * Infinite Scroll
 */
 function peony_infinite_scroll_js() {
    if( ! is_singular() ) { ?>
    <script>

	if( peony_params.blog_pagination_type == 'infinite_scroll' ){
		
		var infinite_scroll = {
        loading: {
            img: "<?php echo get_template_directory_uri(); ?>/images/AjaxLoader.gif",
            msgText: "<?php _e( 'Loading the next set of posts...', 'peony' ); ?>",
            finishedMsg: "<?php _e( 'All posts loaded.', 'peony' ); ?>"
        },
        "nextSelector":"a.next",
        "navSelector":".post-pagination",
        "itemSelector":".entry-box-wrap",
        "contentSelector":".blog-list-wrap"
    };
	
	jQuery('.blog-list-wrap .post-pagination').hide();
    jQuery( infinite_scroll.contentSelector ).infinitescroll( infinite_scroll );
		
		}
    </script>
    <?php
	
    }
}

add_action( 'wp_footer', 'peony_infinite_scroll_js',100 );
	 
  /**
  * Shows a breadcrumb for all types of pages.
  */
  
  function peony_breadcrumb( $args = array() ) {
	if ( function_exists( 'is_bbpress' ) && is_bbpress() )
	  $breadcrumb = new peony_bbPress_Breadcrumb( $args );
	else
	  $breadcrumb = new peony_Breadcrumb( $args );
	return $breadcrumb->trail();
  }
  
  
  /**
  * Creates a breadcrumbs menu for the site based on the current page that's being viewed by the user.
  *
  */
  class peony_Breadcrumb {
  /**
  * Array of items belonging to the current breadcrumb.
  */
  public $items = array();
  /**
  * Arguments used to build the breadcrumb.
  */
  public $args = array();
  /**
  * Sets up the breadcrumb.
  */
  public function __construct( $args = array() ) {
	/* Remove the bbPress breadcrumbs. */
	add_filter( 'bbp_get_breadcrumb', '__return_false' );
	$defaults = array(
	'container' => 'div',
	'separator' => '&#47;',
	'before' => '',
	'after' => '',
	'show_on_front' => true,
	'network' => false,
	//'show_edit_link' => false,
	'show_title' => true,
	'show_browse' => true,
	'echo' => true,
	/* Post taxonomy (examples follow). */
	'post_taxonomy' => array(
	  'portfolio' => 'portfolio_category',
	// 'book' => 'genre',
	),

	'labels' => array()
	);
	$this->args = apply_filters( 'breadcrumb_trail_args', wp_parse_args( $args, $defaults ) );
	/* Merge the user-added labels with the defaults. */
	$this->args['labels'] = wp_parse_args( $this->args['labels'], $this->default_labels() );
	$this->do_trail_items();
  }
  /**
  * Formats and outputs the breadcrumb.
  */
  public function trail() {
	$breadcrumb = '';
	
	if ( !empty( $this->items ) && is_array( $this->items ) ) {

	$this->items = array_unique( $this->items );
	
	$breadcrumb = "\n\t\t" . '<' . tag_escape( $this->args['container'] ) . ' class="breadcrumb-trail breadcrumbs" itemprop="breadcrumb">';
	
	$breadcrumb .= ( !empty( $this->args['before'] ) ? "\n\t\t\t" . '<span class="trail-before">' . $this->args['before'] . '</span> ' . "\n\t\t\t" : '' );
	
	if ( true === $this->args['show_browse'] )
	$breadcrumb .= "\n\t\t\t" . '<span class="trail-browse">' . $this->args['labels']['browse'] . '</span> ';
	
	if ( 1 < count( $this->items ) )
	array_unshift( $this->items, '<span class="trail-begin">' . array_shift( $this->items ) . '</span>' );
	
	array_push( $this->items, '<span class="trail-end">' . array_pop( $this->items ) . '</span>' );
	
	$separator = ( !empty( $this->args['separator'] ) ? '<span class="sep">' . $this->args['separator'] . '</span>' : '<span class="sep">/</span>' );
	
	$breadcrumb .= join( "\n\t\t\t {$separator} ", $this->items );
	
	$breadcrumb .= ( !empty( $this->args['after'] ) ? "\n\t\t\t" . ' <span class="trail-after">' . $this->args['after'] . '</span>' : '' );
	
	$breadcrumb .= "\n\t\t" . '</' . tag_escape( $this->args['container'] ) . '>';
	}
	
	$breadcrumb = apply_filters( 'breadcrumb_trail', $breadcrumb, $this->args );
	if ( true === $this->args['echo'] )
	 echo $breadcrumb;
	else
	return $breadcrumb;
  }
  /**
  * Returns an array of the default labels.
  */
  public function default_labels() {
	$labels = array(
	'browse' => __( 'Browse:', 'peony' ),
	'home' => __( 'Home', 'peony' ),
	'error_404' => __( '404 Not Found', 'peony' ),
	'archives' => __( 'Archives', 'peony' ),
	'search' => __( 'Search results for &#8220;%s&#8221;', 'peony' ),
	'paged' => __( 'Page %s', 'peony' ),
	'archive_minute' => __( 'Minute %s', 'peony' ),
	'archive_week' => __( 'Week %s', 'peony' ),
	'archive_minute_hour' => '%s',
	'archive_hour' => '%s',
	'archive_day' => '%s',
	'archive_month' => '%s',
	'archive_year' => '%s',
	);
	return $labels;
  }
  /**
  * Runs through the various WordPress conditional tags to check the current page being viewed. Once
  * a condition is met, a specific method is launched to add items to the $items array.
  */
  public function do_trail_items() {
	/* If viewing the front page. */
	if ( is_front_page() ) {
	$this->do_front_page_items();
	}
	/* If not viewing the front page. */
	else {
	/* Add the network and site home links. */
	$this->do_network_home_link();
	$this->do_site_home_link();
	/* If viewing the home/blog page. */
	if ( is_home() ) {
	$this->do_posts_page_items();
	}
	/* If viewing a single post. */
	elseif ( is_singular() ) {
	$this->do_singular_items();
	}
	/* If viewing an archive page. */
	elseif ( is_archive() ) {
	if ( is_post_type_archive() )
	$this->do_post_type_archive_items();
	elseif ( is_category() || is_tag() || is_tax() )
	$this->do_term_archive_items();
	elseif ( is_author() )
	$this->do_user_archive_items();
	elseif ( get_query_var( 'minute' ) && get_query_var( 'hour' ) )
	$this->do_minute_hour_archive_items();
	elseif ( get_query_var( 'minute' ) )
	$this->do_minute_archive_items();
	elseif ( get_query_var( 'hour' ) )
	$this->do_hour_archive_items();
	elseif ( is_day() )
	$this->do_day_archive_items();
	elseif ( get_query_var( 'w' ) )
	$this->do_week_archive_items();
	elseif ( is_month() )
	$this->do_month_archive_items();
	elseif ( is_year() )
	$this->do_year_archive_items();
	else
	$this->do_default_archive_items();
	}
	/* If viewing a search results page. */
	elseif ( is_search() ) {
	$this->do_search_items();
	}
	/* If viewing the 404 page. */
	elseif ( is_404() ) {
	$this->do_404_items();
	}
	}
	/* Add paged items if they exist. */
	$this->do_paged_items();
	$this->items = apply_filters( 'breadcrumb_trail_items', $this->items, $this->args );
  }
  /**
  * Gets front items based on $wp_rewrite->front.
  */
  public function do_rewrite_front_items() {
	global $wp_rewrite;
	if ( $wp_rewrite->front )
	$this->do_path_parents( $wp_rewrite->front );
  }
  /**
  * Adds the page/paged number to the items array.
  */
  public function do_paged_items() {
	/* If viewing a paged singular post. */
	if ( is_singular() && 1 < get_query_var( 'paged' ) && true === $this->args['show_title'] )
	$this->items[] = sprintf( $this->args['labels']['paged'], number_format_i18n( absint( get_query_var( 'paged' ) ) ) );
	/* If viewing a paged archive-type page. */
	elseif ( is_paged() && true === $this->args['show_title'] )
	$this->items[] = sprintf( $this->args['labels']['paged'], number_format_i18n( absint( get_query_var( 'paged' ) ) ) );
  }
  /**
  * Adds the network (all sites) home page link to the items array.
  */
  public function do_network_home_link() {
	if ( is_multisite() && !is_main_site() && true === $this->args['network'] )
	$this->items[] = '<a href="' . network_home_url() . '" title="' . esc_attr( $this->args['labels']['home'] ) . '" rel="home">' . $this->args['labels']['home'] . '</a>';
  }
  /**
  * Adds the current site's home page link to the items array.
  */
  public function do_site_home_link() {
	$label = ( is_multisite() && !is_main_site() && true === $this->args['network'] ) ? get_bloginfo( 'name' ) : $this->args['labels']['home'];
	$rel = ( is_multisite() && !is_main_site() && true === $this->args['network'] ) ? '' : ' rel="home"';
	$this->items[] = '<a href="' . home_url() . '" title="' . esc_attr( get_bloginfo( 'name' ) ) . '"' . $rel .'>' . $label . '</a>';
  }
  /**
  * Adds items for the front page to the items array.
  */
  public function do_front_page_items() {
	  /* Only show front items if the 'show_on_front' argument is set to 'true'. */
	  if ( true === $this->args['show_on_front'] || is_paged() || ( is_singular() && 1 < get_query_var( 'paged' ) ) ) {
	  /* If on a paged view, add the home link items. */
	  if ( is_paged() ) {
	  $this->do_network_home_link();
	  $this->do_site_home_link();
	  }
	  /* If on the main front page, add the network home link item and the home item. */
	  else {
	  $this->do_network_home_link();
	  if ( true === $this->args['show_title'] )
	  $this->items[] = ( is_multisite() && true === $this->args['network'] ) ? get_bloginfo( 'name' ) : $this->args['labels']['home'];
	  }
	  }
  }
  /**
  * Adds items for the posts page (i.e., is_home()) to the items array.
  */
  public function do_posts_page_items() {
	  /* Get the post ID and post. */
	  $post_id = get_queried_object_id();
	  $post = get_page( $post_id );
	  if ( 0 < $post->post_parent )
	  $this->do_post_parents( $post->post_parent );
	  /* Get the page title. */
	  $title = get_the_title( $post_id );
	  /* Add the posts page item. */
	  if ( is_paged() )
	  $this->items[] = '<a href="' . get_permalink( $post_id ) . '" title="' . esc_attr( $title ) . '">' . $title . '</a>';
	  elseif ( $title && true === $this->args['show_title'] )
	  $this->items[] = $title;
  }
  /**
  * Adds singular post items to the items array.
  */
  public function do_singular_items() {
	  
	   $show_categories        = peony_option('breadcrumb_show_categories');
	   $show_post_type_archive = peony_option('breadcrumb_show_post_type_archive');
	  /* Get the queried post. */
	  $post = get_queried_object();
	  $post_id = get_queried_object_id();
	  
	  if( $show_categories == '1'){
	  if ( 0 < $post->post_parent )
	  $this->do_post_parents( $post->post_parent );
	  /* If the post doesn't have a parent, get its hierarchy based off the post type. */
	  else
	  $this->do_post_hierarchy( $post_id );
	  }
	  if( $show_post_type_archive == '1'){
	  /* Display terms for specific post type taxonomy if requested. */
	  $this->do_post_terms( $post_id );
	  }
	  /* End with the post title. */
	  if ( $post_title = single_post_title( '', false ) ) {
	  if ( 1 < get_query_var( 'paged' ) )
	  $this->items[] = '<a href="' . get_permalink( $post_id ) . '" title="' . esc_attr( $post_title ) . '">' . $post_title . '</a>';
	  elseif ( true === $this->args['show_title'] )
	  $this->items[] = (strlen($post_title)>23?substr($post_title,0,20 ).'...':$post_title );
	  }
  }
  /**
  * Adds a specific post's parents to the items array.
  */
  public function do_post_parents( $post_id ) {
	  $parents = array();
	  while ( $post_id ) {
	  /* Get the post by ID. */
	  $post = get_post( $post_id );
	  /* Add the formatted post link to the array of parents. */
	  $parents[] = '<a href="' . get_permalink( $post_id ) . '" title="' . esc_attr( get_the_title( $post_id ) ) . '">' . get_the_title( $post_id ) . '</a>';
	  /* If there's no longer a post parent, brea out of the loop. */
	  if ( 0 >= $post->post_parent )
	  break;
	  /* Change the post ID to the parent post to continue looping. */
	  $post_id = $post->post_parent;
	  }
	  /* Get the post hierarchy based off the final parent post. */
	  
	  $this->do_post_hierarchy( $post_id );
	  /* Merge the parent items into the items array. */
	  $this->items = array_merge( $this->items, array_reverse( $parents ) );
  }
  /**
  * Adds a post's terms from a specific taxonomy to the items array.
  */
  public function do_post_terms( $post_id ) {
	  /* Get the post type. */
	  $post_type = get_post_type( $post_id );
	  /* Add the terms of the taxonomy for this post. */
	  if ( !empty( $this->args['post_taxonomy'][ $post_type ] ) )
	  $this->items[] = get_the_term_list( $post_id, $this->args['post_taxonomy'][ $post_type ], '', ', ', '' );
	  }
	 
	  public function do_post_hierarchy( $post_id ) {
	  /* Get the post type. */
	  $post_type = get_post_type( $post_id );
	  $post_type_object = get_post_type_object( $post_type );
	  /* If this is the 'post' post type, get the rewrite front items and map the rewrite tags. */
	  if ( 'post' === $post_type ) {
	  
	  $this->do_rewrite_front_items();
	  /* Map the rewrite tags. */
	  $this->map_rewrite_tags( $post_id, get_option( 'permalink_structure' ) );
	  }
	  /* If the post type has rewrite rules. */
	  elseif ( false !== $post_type_object->rewrite ) {
	  if ( $post_type_object->rewrite['with_front'] )
	  $this->do_rewrite_front_items();
	  /* If there's a path, check for parents. */
	  if ( !empty( $post_type_object->rewrite['slug'] ) )
	  $this->do_path_parents( $post_type_object->rewrite['slug'] );
	  }
	  if ( !empty( $post_type_object->has_archive ) ) {
	  /* Add support for a non-standard label of 'archive_title' (special use case). */
	  $label = !empty( $post_type_object->labels->archive_title ) ? $post_type_object->labels->archive_title : $post_type_object->labels->name;
	  $this->items[] = '<a href="' . get_post_type_archive_link( $post_type ) . '">' . $label . '</a>';
	  }
  }
  /**
  * Gets post types by slug. This is needed because the get_post_types() function doesn't exactly
  */
  public function get_post_types_by_slug( $slug ) {
	  $return = array();
	  $post_types = get_post_types( array(), 'objects' );
	  foreach ( $post_types as $type ) {
	  if ( $slug === $type->has_archive || ( true === $type->has_archive && $slug === $type->rewrite['slug'] ) )
	  $return[] = $type;
	  }
	  return $return;
  }
  
  public function do_term_archive_items() {
	  global $wp_rewrite;
	  /* Get some taxonomy and term variables. */
	  $term = get_queried_object();
	  $taxonomy = get_taxonomy( $term->taxonomy );
	  /* If there are rewrite rules for the taxonomy. */
	  if ( false !== $taxonomy->rewrite ) {
	  if ( $taxonomy->rewrite['with_front'] && $wp_rewrite->front )
	  $this->do_rewrite_front_items();
	  /* Get parent pages by path if they exist. */
	  $this->do_path_parents( $taxonomy->rewrite['slug'] );
	  /* Add post type archive if its 'has_archive' matches the taxonomy rewrite 'slug'. */
	  if ( $taxonomy->rewrite['slug'] ) {
	  $slug = trim( $taxonomy->rewrite['slug'], '/' );
	 
	  $matches = explode( '/', $slug );
	  /* If matches are found for the path. */
	  if ( isset( $matches ) ) {
	  /* Reverse the array of matches to search for posts in the proper order. */
	  $matches = array_reverse( $matches );
	  /* Loop through each of the path matches. */
	  foreach ( $matches as $match ) {
	  /* If a match is found. */
	  $slug = $match;
	  /* Get public post types that match the rewrite slug. */
	  $post_types = $this->get_post_types_by_slug( $match );
	  if ( !empty( $post_types ) ) {
	  $post_type_object = $post_types[0];
	  /* Add support for a non-standard label of 'archive_title' (special use case). */
	  $label = !empty( $post_type_object->labels->archive_title ) ? $post_type_object->labels->archive_title : $post_type_object->labels->name;
	  $this->items[] = '<a href="' . get_post_type_archive_link( $post_type_object->name ) . '" title="' . esc_attr( $label ) . '">' . $label . '</a>';
	  /* Break out of the loop. */
	  break;
	  }
	  }
	  }
	  }
	  }
	  /* If the taxonomy is hierarchical, list its parent terms. */
	  if ( is_taxonomy_hierarchical( $term->taxonomy ) && $term->parent )
	  $this->do_term_parents( $term->parent, $term->taxonomy );
	  if ( is_paged() )
	  $this->items[] = '<a href="' . esc_url( get_term_link( $term, $term->taxonomy ) ) . '" title="' . esc_attr( single_term_title( '', false ) ) . '">' . single_term_title( '', false ) . '</a>';
	  elseif ( true === $this->args['show_title'] )
	  $this->items[] = single_term_title( '', false );
  }
 
  public function do_post_type_archive_items() {
	  /* Get the post type object. */
	  $post_type_object = get_post_type_object( get_query_var( 'post_type' ) );
	  if ( false !== $post_type_object->rewrite ) {
	  if ( $post_type_object->rewrite['with_front'] )
	  $this->do_rewrite_front_items();
	  /* If there's a rewrite slug, check for parents. */
	  if ( !empty( $post_type_object->rewrite['slug'] ) )
	  $this->do_path_parents( $post_type_object->rewrite['slug'] );
	  }
	  if ( is_paged() )
	  $this->items[] = '<a href="' . esc_url( get_post_type_archive_link( $post_type_object->name ) ) . '" title="' . esc_attr( post_type_archive_title( '', false ) ) . '">' . post_type_archive_title( '', false ) . '</a>';
	  elseif ( true === $this->args['show_title'] )
	  $this->items[] = post_type_archive_title( '', false );
  }
  /**
  * Adds the items to the trail items array for user (author) archives.
  */
  public function do_user_archive_items() {
	  global $wp_rewrite;
	  
	  $this->do_rewrite_front_items();
	  /* Get the user ID. */
	  $user_id = get_query_var( 'author' );
	  /* If $author_base exists, check for parent pages. */
	  if ( !empty( $wp_rewrite->author_base ) )
	  $this->do_path_parents( $wp_rewrite->author_base );
	  if ( is_paged() )
	  $this->items[] = '<a href="'. esc_url( get_author_posts_url( $user_id ) ) . '" title="' . esc_attr( get_the_author_meta( 'display_name', $user_id ) ) . '">' . get_the_author_meta( 'display_name', $user_id ) . '</a>';
	  elseif ( true === $this->args['show_title'] )
	  $this->items[] = get_the_author_meta( 'display_name', $user_id );
  }

  public function do_minute_hour_archive_items() {
  
	  $this->do_rewrite_front_items();
	  if ( true === $this->args['show_title'] )
	  $this->items[] = sprintf( $this->args['labels']['archive_minute_hour'], get_the_time( _x( 'g:i a', 'minute and hour archives time format', 'peony' ) ) );
  }
 
  public function do_minute_archive_items() {
  
	  $this->do_rewrite_front_items();
	  if ( true === $this->args['show_title'] )
	  $this->items[] = sprintf( $this->args['labels']['archive_minute'], get_the_time( _x( 'i', 'minute archives time format', 'peony' ) ) );
  }
  
  public function do_hour_archive_items() {
  
	  $this->do_rewrite_front_items();
	  if ( true === $this->args['show_title'] )
	  $this->items[] = sprintf( $this->args['labels']['archive_hour'], get_the_time( _x( 'g a', 'hour archives time format', 'peony' ) ) );
  }

  public function do_day_archive_items() {
  
	  $this->do_rewrite_front_items();
	  $year = sprintf( $this->args['labels']['archive_year'], get_the_time( _x( 'Y', 'yearly archives date format', 'peony' ) ) );
	  $month = sprintf( $this->args['labels']['archive_month'], get_the_time( _x( 'F', 'monthly archives date format', 'peony' ) ) );
	  $day = sprintf( $this->args['labels']['archive_day'], get_the_time( _x( 'j', 'daily archives date format', 'peony' ) ) );
	  $this->items[] = '<a href="' . get_year_link( get_the_time( 'Y' ) ) . '" title="' . esc_attr( $year ) . '">' . $year . '</a>';
	  $this->items[] = '<a href="' . get_month_link( get_the_time( 'Y' ), get_the_time( 'm' ) ) . '" title="' . esc_attr( $month ) . '">' . $month . '</a>';
	  if ( is_paged() )
	  $this->items[] = '<a href="' . get_day_link( get_the_time( 'Y' ), get_the_time( 'm' ), get_the_time( 'd' ) ) . '" title="' . esc_attr( $day ) . '">' . $day . '</a>';
	  elseif ( true === $this->args['show_title'] )
	  $this->items[] = $day;
  }

  public function do_week_archive_items() {
  
	  $this->do_rewrite_front_items();
	  $year = sprintf( $this->args['labels']['archive_year'], get_the_time( _x( 'Y', 'yearly archives date format', 'peony' ) ) );
	  $week = sprintf( $this->args['labels']['archive_week'], get_the_time( _x( 'W', 'weekly archives date format', 'peony' ) ) );
	  $this->items[] = '<a href="' . get_year_link( get_the_time( 'Y' ) ) . '" title="' . esc_attr( $year ) . '">' . $year . '</a>';
	  if ( is_paged() )
	  $this->items[] = get_archives_link( add_query_arg( array( 'm' => get_the_time( 'Y' ), 'w' => get_the_time( 'W' ) ), home_url() ), $week, false );
	  elseif ( true === $this->args['show_title'] )
	  $this->items[] = $week;
  }

  public function do_month_archive_items() {
  
	  $this->do_rewrite_front_items();
	  $year = sprintf( $this->args['labels']['archive_year'], get_the_time( _x( 'Y', 'yearly archives date format', 'peony' ) ) );
	  $month = sprintf( $this->args['labels']['archive_month'], get_the_time( _x( 'F', 'monthly archives date format', 'peony' ) ) );
	  $this->items[] = '<a href="' . get_year_link( get_the_time( 'Y' ) ) . '" title="' . esc_attr( $year ) . '">' . $year . '</a>';
	  if ( is_paged() )
	  $this->items[] = '<a href="' . get_month_link( get_the_time( 'Y' ), get_the_time( 'm' ) ) . '" title="' . esc_attr( $month ) . '">' . $month . '</a>';
	  elseif ( true === $this->args['show_title'] )
	  $this->items[] = $month;
  }

  public function do_year_archive_items() {
  
	  $this->do_rewrite_front_items();
	  $year = sprintf( $this->args['labels']['archive_year'], get_the_time( _x( 'Y', 'yearly archives date format', 'peony' ) ) );
	  if ( is_paged() )
	  $this->items[] = '<a href="' . get_year_link( get_the_time( 'Y' ) ) . '" title="' . esc_attr( $year ) . '">' . $year . '</a>';
	  elseif ( true === $this->args['show_title'] )
	  $this->items[] = $year;
  }
  
  public function do_default_archive_items() {
	  if ( is_date() || is_time() )
	  $this->do_rewrite_front_items();
	  if ( true === $this->args['show_title'] )
	  $this->items[] = $this->args['labels']['archives'];
  }
 
  public function do_search_items() {
	  if ( is_paged() )
	  $this->items[] = '<a href="' . get_search_link() . '" title="' . esc_attr( sprintf( $this->args['labels']['search'], get_search_query() ) ) . '">' . sprintf( $this->args['labels']['search'], get_search_query() ) . '</a>';
	  elseif ( true === $this->args['show_title'] )
	  $this->items[] = sprintf( $this->args['labels']['search'], get_search_query() );
  }
  
  public function do_404_items() {
     if ( true === $this->args['show_title'] )
     $this->items[] = $this->args['labels']['error_404'];
  }

  function do_path_parents( $path ) {
	  $path = trim( $path, '/' );
	  if ( empty( $path ) )
	  return;
	  $post = get_page_by_path( $path );
	  if ( !empty( $post ) ) {
	  $this->do_post_parents( $post->ID );
	  }
	  elseif ( is_null( $post ) ) {
	  $path = trim( $path, '/' );
	  preg_match_all( "/\/.*?\z/", $path, $matches );
	  if ( isset( $matches ) ) {
	  $matches = array_reverse( $matches );
	  foreach ( $matches as $match ) {
	  if ( isset( $match[0] ) ) {
	  $path = str_replace( $match[0], '', $path );
	  $post = get_page_by_path( trim( $path, '/' ) );
	  if ( !empty( $post ) && 0 < $post->ID ) {
	  $this->do_post_parents( $post->ID );
	  break;
	  }
	  }
	  }
	  }
	  }
  }

  function do_term_parents( $term_id, $taxonomy ) {
	  $parents = array();
	  while ( $term_id ) {
	  $term = get_term( $term_id, $taxonomy );
	  $parents[] = '<a href="' . get_term_link( $term, $taxonomy ) . '" title="' . esc_attr( $term->name ) . '">' . $term->name . '</a>';
	  $term_id = $term->parent;
	  }
	  if ( !empty( $parents ) )
	  $this->items = array_merge( $this->items, $parents );
  }

  public function map_rewrite_tags( $post_id, $path ) {
	  $post = get_post( $post_id );
	  if ( empty( $post ) || is_wp_error( $post ) || 'post' !== $post->post_type )
	  return $trail;
	  $path = trim( $path, '/' );
	  $matches = explode( '/', $path );
	  if ( is_array( $matches ) ) {
	  foreach ( $matches as $match ) {
	  $tag = trim( $match, '/' );
	  if ( '%year%' == $tag )
	  $this->items[] = '<a href="' . get_year_link( get_the_time( 'Y', $post_id ) ) . '">' . sprintf( $this->args['labels']['archive_year'], get_the_time( _x( 'Y', 'yearly archives date format', 'peony' ) ) ) . '</a>';
	  elseif ( '%monthnum%' == $tag )
	  $this->items[] = '<a href="' . get_month_link( get_the_time( 'Y', $post_id ), get_the_time( 'm', $post_id ) ) . '">' . sprintf( $this->args['labels']['archive_month'], get_the_time( _x( 'F', 'monthly archives date format', 'peony' ) ) ) . '</a>';
	  elseif ( '%day%' == $tag )
	  $this->items[] = '<a href="' . get_day_link( get_the_time( 'Y', $post_id ), get_the_time( 'm', $post_id ), get_the_time( 'd', $post_id ) ) . '">' . sprintf( $this->args['labels']['archive_day'], get_the_time( _x( 'j', 'daily archives date format', 'peony' ) ) ) . '</a>';
	  elseif ( '%author%' == $tag )
	  $this->items[] = '<a href="' . get_author_posts_url( $post->post_author ) . '" title="' . esc_attr( get_the_author_meta( 'display_name', $post->post_author ) ) . '">' . get_the_author_meta( 'display_name', $post->post_author ) . '</a>';
	  elseif ( '%category%' == $tag ) {
	  $this->args['post_taxonomy'][ $post->post_type ] = false;
	  $terms = get_the_category( $post_id );
	  if ( $terms ) {
	  usort( $terms, '_usort_terms_by_ID' );
	  $term = get_term( $terms[0], 'category' );
	  if ( 0 < $term->parent )
	  $this->do_term_parents( $term->parent, 'category' );
	  $this->items[] = '<a href="' . get_term_link( $term, 'category' ) . '" title="' . esc_attr( $term->name ) . '">' . $term->name . '</a>';
		   }
		  }
		 }
		}
	   }
  }
 
  class peony_bbPress_Breadcrumb extends peony_Breadcrumb {

  public function do_trail_items() {
	$this->do_network_home_link();
	$this->do_site_home_link();
	$post_type_object = get_post_type_object( bbp_get_forum_post_type() );
	if ( !empty( $post_type_object->has_archive ) && !bbp_is_forum_archive() )
	$this->items[] = '<a href="' . get_post_type_archive_link( bbp_get_forum_post_type() ) . '">' . bbp_get_forum_archive_title() . '</a>';
	if ( bbp_is_forum_archive() ) {
	if ( true === $this->args['show_title'] )
	$this->items[] = bbp_get_forum_archive_title();
	}
	elseif ( bbp_is_topic_archive() ) {
	if ( true === $this->args['show_title'] )
	$this->items[] = bbp_get_topic_archive_title();
	}
	elseif ( bbp_is_topic_tag() ) {
	if ( true === $this->args['show_title'] )
	$this->items[] = bbp_get_topic_tag_name();
	}
	elseif ( bbp_is_topic_tag_edit() ) {
	$this->items[] = '<a href="' . bbp_get_topic_tag_link() . '">' . bbp_get_topic_tag_name() . '</a>';
	if ( true === $this->args['show_title'] )
	$this->items[] = __( 'Edit', 'peony' );
	}
	elseif ( bbp_is_single_view() ) {
	if ( true === $this->args['show_title'] )
	$this->items[] = bbp_get_view_title();
	}
	elseif ( bbp_is_single_topic() ) {
	$topic_id = get_queried_object_id();
	$this->do_post_parents( bbp_get_topic_forum_id( $topic_id ) );
	if ( bbp_is_topic_split() || bbp_is_topic_merge() || bbp_is_topic_edit() )
	$this->items[] = '<a href="' . bbp_get_topic_permalink( $topic_id ) . '">' . bbp_get_topic_title( $topic_id ) . '</a>';
	elseif ( true === $this->args['show_title'] )
	$this->items[] = bbp_get_topic_title( $topic_id );
	if ( bbp_is_topic_split() && true === $this->args['show_title'] )
	$this->items[] = __( 'Split', 'peony' );
	elseif ( bbp_is_topic_merge() && true === $this->args['show_title'] )
	$this->items[] = __( 'Merge', 'peony' );
	elseif ( bbp_is_topic_edit() && true === $this->args['show_title'] )
	$this->items[] = __( 'Edit', 'peony' );
	}
	elseif ( bbp_is_single_reply() ) {
	$reply_id = get_queried_object_id();
	$this->do_post_parents( bbp_get_reply_topic_id( $reply_id ) );
	if ( bbp_is_reply_edit() ) {
	$this->items[] = '<a href="' . bbp_get_reply_url( $reply_id ) . '">' . bbp_get_reply_title( $reply_id ) . '</a>';
	if ( true === $this->args['show_title'] )
	$this->items[] = __( 'Edit', 'peony' );
	} elseif ( true === $this->args['show_title'] ) {
	$this->items[] = bbp_get_reply_title( $reply_id );
	}
	}
	elseif ( bbp_is_single_forum() ) {
	$forum_id = get_queried_object_id();
	$forum_parent_id = bbp_get_forum_parent_id( $forum_id );
	if ( 0 !== $forum_parent_id)
	$this->do_post_parents( $forum_parent_id );
	if ( true === $this->args['show_title'] )
	$this->items[] = bbp_get_forum_title( $forum_id );
	}
	elseif ( bbp_is_single_user() || bbp_is_single_user_edit() ) {
	if ( bbp_is_single_user_edit() ) {
	$this->items[] = '<a href="' . bbp_get_user_profile_url() . '">' . bbp_get_displayed_user_field( 'display_name' ) . '</a>';
	if ( true === $this->args['show_title'] )
	$this->items[] = __( 'Edit', 'peony' );
	} elseif ( true === $this->args['show_title'] ) {
	$this->items[] = bbp_get_displayed_user_field( 'display_name' );
	}
	}
	$this->items = apply_filters( 'breadcrumb_trail_get_bbpress_items', $this->items, $this->args );
	}
  }
  
 
/**
 * Selective Refresh
 */
  function peony_register_blogname_partials( WP_Customize_Manager $wp_customize ) {
	  
		  // Abort if selective refresh is not available.
		if ( ! isset( $wp_customize->selective_refresh ) ) {
			return;
		}
 
   	    $customizer_library = Customizer_Library::Instance();

		$options = $customizer_library->get_options();

		// Bail early if we don't have any options.
		if ( empty( $options ) ) {
			return;
		}

		// Loops through each of the options
		foreach ( $options as $option ) {
			
		if( isset($option['id']) ){
			$wp_customize->selective_refresh->add_partial( $option['id'].'_selective', array(
        'selector' => '.'.$option['id'],
        'settings' => array( $option['id'] ),
        'render_callback' => function() {
          
        },
    ) );
		}
			
		}
    
    $wp_customize->selective_refresh->add_partial( 'header_site_title', array(
        'selector' => '.site-name',
        'settings' => array( 'blogname' ),
        'render_callback' => function() {
           // return get_bloginfo( 'name', 'display' );
        },
    ) );
	
	$wp_customize->selective_refresh->add_partial( 'header_site_description', array(
        'selector' => '.site-tagline',
        'settings' => array( 'blogdescription' ),
        'render_callback' => function() {
           // return get_bloginfo( 'name', 'display' );
        },
    ) );
 

}
add_action( 'customize_register', 'peony_register_blogname_partials' );