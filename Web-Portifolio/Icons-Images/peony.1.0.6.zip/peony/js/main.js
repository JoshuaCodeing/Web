jQuery(document).ready(function($){
		// home page						
	$('.peony-section-slider .slide').each(function(){
		$(this).css({'min-height':$(window).height()});
	});

  $(function(){
	  $('#peony-main').fullpage({
		  anchors: JSON.parse(peony_params.anchors),
		  onLeave: function(index, nextIndex, direction){
		  
			  var th = $(".section").eq(index);
			  if (direction == "down")
			  {
				$(th).prev().addClass("from-next");
			  }
			  else if (direction == "up") {
				  $(th).prev().addClass("from-prev");
			  }
		  },
		  afterLoad: function(anchorLink, index){
			  $(".section").removeClass("from-next from-prev");
			  			  
		  }
	  });
	  
	  $(".slider-carousel").owlCarousel({
		  items: 1,
	  });
	  $(".peony-gallery-carousel").owlCarousel({
		  items: 4,
		
	  });
	  $(".peony-blog-carousel").owlCarousel({
		  items: peony_params.blog_carousel_col,
		  
	  });
	  
	  $(".site-nav-toggle").click(function(){
		  $(".site-nav").animate({right:"0"});
		  $(this).hide();
	  })
	  $(".site-nav .close").click(function(){
		  $(".site-nav").animate({right:"-300px"});
		  $(".site-nav-toggle").show();
	  });
	  $(".site-nav li.parent a").click(function(){
		  $(this).closest("li").children("ul").slideToggle();
	  });
  });
		
 $('.site-nav > ul').find('li.menu-item-has-children').addClass('parent');
 $('.site-nav > ul li').find('ul.sub-menu').addClass('sub');
			
//prettyPhoto
 
 $("a[rel^='prettyPhoto']").prettyPhoto();	
// gallery lightbox
 $(".gallery .gallery-item a").prettyPhoto({animation_speed:'fast',slideshow:10000, hideflash: true});
// tool tip
$('[data-toggle="tooltip"]').tooltip(); 

// back to top button
$('.scroll-to-top').click(function(){
								   
		var peony_main = $('#peony-home-sections #peony-main');	
		var previousDestTop = 0;
		var $window    = $(window);
		windowsHeight   = $window.height(); 
		if( peony_main.length ){
			  var elemPosition = peony_main.position();

            //top of the desination will be at the top of the viewport
            var position = elemPosition.top;
            var isScrollingDown =  elemPosition.top > previousDestTop;
            var sectionBottom = position - windowsHeight + peony_main.outerHeight();

            //is the destination element bigger than the viewport?
            if(peony_main.outerHeight() > windowsHeight){
                //scrolling up?
                if(!isScrollingDown){
                    position = sectionBottom;
                }
            }

            //sections equal or smaller than the viewport height && scrolling down? ||  is resizing and its in the last section
            else if(isScrollingDown || (isResizing && peony_main.is(':last-child')) ){
                //The bottom of the destination will be at the bottom of the viewport
                position = sectionBottom;
            }

        var translate3d = 'translate3d(0px, -' + position + 'px, 0px)';
		peony_main.css({
                '-webkit-transform': translate3d,
                '-moz-transform': translate3d,
                '-ms-transform':translate3d,
                'transform': translate3d
            });
		}
        $('html, body').animate({scrollTop:0},1000);
		return false;
    });

// side menu
 $('.site-nav > ul').find('li.menu-item-has-children').addClass('parent');
 $('.site-nav ul li.menu-item-has-children > a').after('<span class="menu-item-toggle"></span>');
 $('.site-nav > ul li').find('ul.sub-menu').addClass('sub');

  $(document).on( 'click','span.menu-item-toggle',function(e){
	 $(this).next('.sub-menu').slideToggle('fast');
 });
  

});


function peony_initialize() {
	
	var geocoder;
	var map;
	var address = peony_params.gmap_address;

  geocoder = new google.maps.Geocoder();
  var latlng = new google.maps.LatLng(-34.397, 150.644);
  var myOptions = {
    zoom: 8,
    center: latlng,
    mapTypeControl: true,
    mapTypeControlOptions: {
      style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
    },
    navigationControl: true,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  };
  map = new google.maps.Map(document.getElementById("peony_map_canvas"), myOptions);
  if (geocoder) {
    geocoder.geocode({
      'address': address
    }, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
        if (status != google.maps.GeocoderStatus.ZERO_RESULTS) {
          map.setCenter(results[0].geometry.location);

          var infowindow = new google.maps.InfoWindow({
            content: '<b>' + address + '</b>',
            size: new google.maps.Size(150, 50)
          });

          var marker = new google.maps.Marker({
            position: results[0].geometry.location,
            map: map,
            title: address
          });
          google.maps.event.addListener(marker, 'click', function() {
            infowindow.open(map, marker);
          });

        } else {
          alert("No results found");
        }
      } else {
        alert("Geocode was not successful for the following reason: " + status);
      }
    });
  }
}
if (typeof google === 'object' && typeof google.maps === 'object') {
	google.maps.event.addDomListener(window, 'load', peony_initialize);
}


jQuery(window).on('load', function($){
	// blog grid
jQuery('.blog-grid').masonry({
	// options
	itemSelector : '.entry-box-wrap',
	animate: true
	});	

 });