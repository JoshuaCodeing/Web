<?php
/*
  Template Name: Front Page
 */
get_header('home'); 
?>
<div id="peony-home-sections">
<div class="page-content" role="main" id="peony-main">

<?php
global $peony_homepage_sections,$peony_header_home,$peony_footer_home;

  $header_overlay = peony_option('header_overlay');
  
  $nav_menu   =  'primary';
 
  $overlay = '';
  if( $header_overlay == '1')
  $overlay = 'overlay';
  
  
	  
  $custom_logo_id = get_theme_mod( 'custom_logo' );
  $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
  $logo  =  $image[0];
						
  $i = 1;
  $j = 1;
  $actived_sections = array();
  
  foreach(  $peony_homepage_sections as $k=>$v ){
	  $hide = peony_option('section_'.$k.'_hide');
	  if( $hide != '1' ){
		  $actived_sections[] = $k;
		  }
		  $j++;
  }
  $actived_sections_num = count($actived_sections);
  
  foreach(  $peony_homepage_sections as $k=>$v ){
	$hide = peony_option('section_'.$k.'_hide');
	$peony_header_home = '';
	$peony_footer_home = '';
	if( $hide != '1' ){
	if(isset( $actived_sections[0]) && $actived_sections[0] == $k)	:
	$peony_header_home .= '<header id="header" class="logo-left '.$overlay.'">
					<div class="container">
						<div class="logo-box text-left">
							  <a href="'.esc_url(home_url('/')).'">';
                   if( $logo ):
                   $peony_header_home .= '<img class="site-logo normal_logo peony_standard_logo" alt="'.get_bloginfo('name').'" src="'.esc_url($logo).'" >';
							endif;
					
					$peony_header_home .= '</a>
							<div class="name-box">
								 <a href="'.esc_url(home_url('/')).'"><h1 class="site-name">'.get_bloginfo('name').'</h1></a>
                                <span class="site-tagline">'.get_bloginfo('description').'</span>
							</div>
						</div>
						<a class="site-nav-toggle">
							<span class="sr-only">'.__( 'Toggle navigation', 'peony' ).'</span>
							<i class="fa fa-bars"></i>
						</a>
					</div>
					<nav class="site-nav">
					<h1 class="text-right">'.get_bloginfo('name').'</h1>
						<button type="button" class="close" aria-label="'.__( 'Close', 'peony' ).'"><span aria-hidden="true">&times;</span></button>
						 ';

 $peony_header_home .= wp_nav_menu(array('theme_location'=>$nav_menu,'depth'=>0,'fallback_cb' =>false,'container'=>'','container_class'=>'main-menu','menu_id'=>'menu-main','menu_class'=>'main-nav','link_before' => '<span class="menu-item-label">', 'link_after' => '</span>','items_wrap'=> '<ul id="%1$s" class="%2$s">%3$s</ul>','echo'=>false));
 $peony_header_home .= '</nav></header>';
 endif;
 
 if(isset( $actived_sections[$actived_sections_num-1]) && $actived_sections[$actived_sections_num-1] == $k)	:
  $enable_tooltip  = esc_attr(peony_option('enable_tooltip'));
							   if($enable_tooltip == '1')
							   $tooltip = 'tooltip';
							   else
							   $tooltip = '';
	$peony_footer_home = '<footer style="position: absolute; bottom: 0; left: 0; width: 100%;">
					<div class="footer-info-area">
						<div class="container text-center">
							<div class="row">
								<div class="col-md-4 text-left">
									<div class="site-info">
										'.sprintf(__('Designed by <a href="%s">Magee Theme</a>. All Rights Reserved.', 'peony' ),esc_url('http://www.mageewp.com/')).'
									</div>
								</div>
								<div class="col-md-4 text-center">
									<ul class="footer-sns peony_footer_social_icon_1">';
					for( $j=1;$j<=8;$j++ ){
					
					$social_icon  = esc_attr(peony_option('footer_social_icon_'.$j));
					$social_title = esc_attr(peony_option('footer_social_title_'.$j));
					$social_link  = esc_url(peony_option('footer_social_link_'.$j));
					if( $social_icon != '' ){
						$social_icon  = 'fa-'.str_replace('fa-','',$social_icon);
					$peony_footer_home .= '<li><a href="'.$social_link.'" title="'.$social_title.'" data-placement="top" data-toggle="'.$tooltip.'" target="_blank"><i class="fa '.$social_icon.'"></i></a></li>';
					}
					}		
										
					$peony_footer_home .= '</ul>									
								</div>
								<div class="col-md-4 text-right">
									<a href="javascript:;" class="scroll-to-top"><i class="fa fa-angle-up"></i></a>
								</div>
							</div>							
						</div>
					</div>			
				</footer>';
	
endif;
 get_template_part('home-sections/section',$k);
 
 	}
 $i++;
 
}
?> 
</div>
</div>
<?php get_footer('home'); 