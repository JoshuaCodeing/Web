<?php
  global $peony_header_home,$peony_footer_home, $allowedposttags;

  $title = wp_kses(peony_option( 'gallery_title' ), $allowedposttags);
  $subtitle = wp_kses(peony_option( 'gallery_subtitle'), $allowedposttags);
  $page_id  = wp_kses(peony_option( 'gallery_description'), $allowedposttags);
  $btn_text = esc_attr(peony_option( 'gallery_btn_text'));;
  $btn_target = esc_attr(peony_option( 'gallery_btn_target'));
  
  $btn_link  = '';
  $description  = '';
  
  if( $peony_footer_home != '' )
    $section_class = 'section-footer';
  else
    $section_class = '';
?>
<section class="section section-gallery <?php echo $section_class;?>"><?php echo $peony_header_home; ?>
  
  <div class="section-content peony-section-gallery">
    <div class="container-fullwidth">
      <div class="peony-carousel-wrap full">
        <div class="peony-carousel owl-carousel peony-gallery-carousel">
          <div class="peony-gallery-item peony-gallery-main">
            <div class="section-title-wrap text-left">
              <h1 class="section-title peony_gallery_title"><?php echo $title;?></h1>
              <p class="section-subtitle sm-wrap peony_gallery_subtitle"><?php echo do_shortcode($subtitle);?></p>
            </div>
            <?php
if( $page_id  > 0 ){
			 $query = new WP_Query( array( 'page_id' => $page_id ) );
			  if ( $query->have_posts() ) :
				  while ( $query->have_posts() ) :
					  $query->the_post();

			  $btn_link = esc_url(get_permalink($page_id));
			  $description = get_the_content();

			  endwhile;
			  endif;
			   wp_reset_query();
			}
?>
            <p class="peony_gallery_description"><?php echo do_shortcode($description);?></p>
            <?php if( $btn_text != '' ):?>
            <a href="<?php echo  $btn_link;?>" target="<?php echo  $btn_target;?>" class="peony-btn peony_gallery_btn_text"><?php echo do_shortcode($btn_text);?></a>
            <?php endif;?>
          </div>
          <?php
								for( $i = 1; $i<=3; $i++ ){
									$image = esc_url( peony_option( 'gallery_image_'.$i));
									$title  = esc_attr( peony_option( 'gallery_title_'.$i));
									$desc   = esc_attr( peony_option( 'gallery_desc_'.$i));
									$btn_link = '#';
									if($desc  > 0 ){
									 $query = new WP_Query( array( 'page_id' => $desc ) );
									  if ( $query->have_posts() ) :
										  while ( $query->have_posts() ) :
											  $query->the_post();
											  
									  $btn_link = esc_url( get_permalink($desc ) );
									  $desc = get_the_content();  
									  endwhile;
									  endif;
									   wp_reset_query();
									}
									$btn_target = esc_attr(peony_option( 'gallery_btn_target_'.$i));
									$btn_text = esc_attr(peony_option( 'gallery_more_text_'.$i));
								?>
          <div class="peony-gallery-item" style="background-image: url(<?php echo  $image;?>);">
            <div class="peony-gallery-item-overlay">
              <h3 class="title peony_gallery_title_<?php echo $i;?>"><?php echo  $title;?></h3>
              <p class="desc peony_gallery_desc_<?php echo $i;?>"><?php echo do_shortcode($desc);?></p>
              <a href="<?php echo  $btn_link;?>" class="peony_gallery_more_text_<?php echo $i;?>" target="<?php echo  $btn_target;?>"><?php echo  $btn_text;?></a> </div>
          </div>
          <?php }?>
        </div>
      </div>
    </div>
  </div>
  <?php echo $peony_footer_home;?> </section>