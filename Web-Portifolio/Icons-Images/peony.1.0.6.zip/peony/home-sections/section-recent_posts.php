<?php
  global $peony_header_home,$peony_footer_home, $allowedposttags;

  $title = wp_kses(peony_option( 'recent_posts_title' ), $allowedposttags);
  $subtitle = wp_kses(peony_option( 'recent_posts_sub_title'), $allowedposttags);

  if( $peony_footer_home != '' )
 $section_class = 'section-footer';
else
 $section_class = '';
?>

<section class="section section-recent_posts <?php echo $section_class;?>">			
				<div class="section-content">
					<div class="container">
						<div class="section-title-wrap text-center">
							<h1 class="section-title peony_recent_posts_title"><?php echo $title;?></h1>
							<p class="section-subtitle sm-wrap peony_recent_posts_sub_title"><?php echo do_shortcode($subtitle);?></p>
						</div>
						<div class="peony-carousel-wrap">
							<div class="peony-carousel owl-carousel peony-blog-carousel">
<?php
	 $news_item = '';
	 $posts_num = absint(peony_option('blog_num'));
	 $my_posts  = new WP_Query( 'ignore_sticky_posts=1&posts_per_page='.$posts_num );

// The Loop
while ($my_posts -> have_posts() ) : $my_posts -> the_post();  
     $post_id = get_the_ID();
     $comments_count = wp_count_comments( $post_id );
     $featured_image = '';
	 $wrap_class = 'no-feature-image';
	if( has_post_thumbnail()  ){
		$image_thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post_id ) );
		$image_full  = wp_get_attachment_image_src( get_post_thumbnail_id($post_id ), "full" );
		$featured_image = '<div class="entry-image">
										<div class="img-box figcaption-middle text-center fade-in">
											<img src="'.esc_url($image_thumb[0]).'" alt="">
											<div class="img-overlay">
												<div class="img-overlay-container">
													<div class="img-overlay-content">
														<div class="img-overlay-icons">
		                                               		<a href="'.esc_url(get_permalink()).'"><i class="fa fa-link"></i></a>
		                                                	<a href="'.esc_url($image_full[0]).'" rel="prettyPhoto"><i class="fa fa-search"></i></a>
		                                            	</div>
													</div>
												</div>
											</div>
										</div>
									</div>';
									$wrap_class = '';
		}
	
	
	$news_item .= '<div class="peony-entry-wrap '.$wrap_class.'">
									 '.$featured_image.'  
									 <div class="entry-main">
										<div class="entry-header">
											<div class="entry-meta">
												<div class="entry-date">'.esc_attr(get_the_date()).'</div>
											</div>
											<h2 class="entry-title"><a href="'.esc_url(get_permalink()).'">'.esc_attr(get_the_title()).'</a></h2>
										</div>
										<div class="entry-summary">'.peony_get_summary().'</div>
									</div>		
								</div>';
											
											
 
   
endwhile;

// Reset Query
 wp_reset_query();
 echo $news_item;	 

	  ?>      
                                
							</div>						
						</div>
					</div>
				</div>
			</section>
