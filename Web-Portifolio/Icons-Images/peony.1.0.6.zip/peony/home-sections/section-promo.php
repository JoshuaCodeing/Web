<?php
  global $peony_header_home,$peony_footer_home, $allowedposttags;

  $image =  peony_option( 'promo_image') ;
  $title = wp_kses(peony_option( 'promo_title' ), $allowedposttags);
  $subtitle = wp_kses(peony_option( 'promo_subtitle'), $allowedposttags);
  $page_id = absint(peony_option( 'promo_description'));
  $btn_text = esc_attr(peony_option( 'promo_btn_text'));
  $btn_target = esc_attr(peony_option( 'promo_btn_target'));	
  $alignment = esc_attr(peony_option( 'promo_alignment'));	
  $btn_link  = '';
  $description  = '';
  
  if( $peony_footer_home != '' )
   $section_class = 'section-footer';
  else
   $section_class = '';
?>
<section class="section section-promo <?php echo $section_class;?>">
<?php echo $peony_header_home; ?>

<?php
if( $page_id  > 0 ){
			 $query = new WP_Query( array( 'page_id' => $page_id ) );
			  if ( $query->have_posts() ) :
				  while ( $query->have_posts() ) :
					  $query->the_post();

			  $btn_link = esc_url(get_permalink($description));
			  $description = get_the_content();
			  endwhile;
			  endif;
			   wp_reset_query();
			}
?>
			    <!--Section: Promo-->
				<div class="section-content">
					<div class="container">
						<div class="row">
							<div class="col-sm-6 section-bg <?php echo $alignment;?>">
                            <?php if( $image != '' ):?>
								<img src="<?php echo  esc_url($image);?>" alt="" />
                                <?php endif;?>
							</div>
							<div class="col-sm-6 col-lg-5 col-sm-push-6 col-lg-push-7">
								<div class="section-title-wrap text-left">
									<h1 class="section-title peony_promo_title"><?php echo $title;?></h1>
									<p class="section-subtitle peony_promo_subtitle"><?php echo do_shortcode($subtitle);?></p>
								</div>	
                              					
								<p class="peony_promo_description"><?php echo do_shortcode($description);?></p>
                                
                                 <?php if( $btn_text != '' ):?>
								 <a href="<?php echo  $btn_link;?>" target="<?php echo  $btn_target;?>" class="peony-btn peony_promo_btn_text"><?php echo do_shortcode($btn_text);?></a>
                                 <?php endif;?>
							</div>
						</div>
					</div>					
				</div>
                <?php echo $peony_footer_home;?>
</section>