<?php
  global $peony_header_home,$peony_footer_home, $allowedposttags;

  $title      = wp_kses(peony_option( 'contact_title' ), $allowedposttags);
  $subtitle   = wp_kses(peony_option( 'contact_subtitle'), $allowedposttags);
  $btn_text   = esc_attr(peony_option( 'contact_btn_text'));
  $receiver   = esc_attr(peony_option('contact_receiver')); 

  if( $peony_footer_home != '' )
 $section_class = 'section-footer';
else
 $section_class = '';
 
?>
<section class="section section-contact <?php echo $section_class;?>">
<?php echo $peony_header_home; ?>
				<!--Section: Contact-->
				<div class="section-content">
					<div class="container">
						<div class="section-title-wrap text-center">
							<h1 class="section-title peony_contact_title"><?php echo $title;?></h1>
							<p class="section-subtitle sm-wrap peony_contact_subtitle"><?php echo do_shortcode($subtitle);?></p>
						</div>
						<div class="peony-contact row">

                            <div class="peony-contact-info col-md-4">
								<div class="peony-feature-box">
									<div class="icon"><i class="fa fa-map-marker"></i></div>
									<h4 class="title"><?php _e( 'ADDRESS', 'peony' );?>:</h4>
									<address class="text peony_contact_address"><?php  echo esc_attr(peony_option('contact_address')); ?></address>
								</div>
								<div class="peony-feature-box">
									<div class="icon"><i class="fa fa-envelope-o"></i></div>
									<h4 class="title"><?php _e( 'EMAIL', 'peony' );?>:</h4>
									<div class="text peony_contact_email"><a href="mailto:<?php  echo esc_attr(peony_option('contact_email')); ?>"><?php  echo esc_attr(peony_option('contact_email')); ?></a></div>
								</div>
								<div class="peony-feature-box">
									<div class="icon"><i class="fa fa-mobile"></i></div>
									<h4 class="title"><?php _e( 'PHONE', 'peony' );?>:</h4>
									<div class="text peony_contact_phone"><?php  echo esc_attr(peony_option('contact_phone')); ?></div>
								</div>
							</div>
                            
							<div class="peony-contact-form col-md-8">
                            <div id="peony_map_canvas"></div>

							</div>
						</div>
					</div>	
				</div>
                <?php echo $peony_footer_home;?>
			</section>