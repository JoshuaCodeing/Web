<?php
 global $peony_header_home,$peony_footer_home, $allowedposttags;
 
 if( $peony_footer_home != '' )
 $section_class = 'section-footer';
else
 $section_class = '';
 
?>
<section class="section section-slider <?php echo $section_class;?>">
<?php echo $peony_header_home; ?>
<!--Section: Slider-->
<div class="section-content peony-section-slider">

<?php
for( $i=0;$i<5;$i++ ):

        $display  = peony_option( 'slider_display_'.$i);		
	    $image    = esc_url( peony_option( 'slider_image_'.$i));
	    $title    = wp_kses(peony_option( 'slider_title_'.$i ), $allowedposttags);
		$subtitle = wp_kses(peony_option( 'slider_subtitle_'.$i), $allowedposttags);

		if( $display == '1'):
?>
    <div class="slide text-center peony_slider_image_<?php echo  $i;?>" style="background-image: url(<?php echo  $image;?>);">
        <div class="container">
            <div class="section-title-wrap">
                <h1 class="section-title peony_slider_title_<?php echo  $i;?>"><?php echo  do_shortcode($title);?></h1>
                <p class="section-subtitle sm-wrap peony_slider_subtitle_<?php echo  $i;?>"><?php echo do_shortcode($subtitle);?></p>
            </div>
            
        </div>
    </div>
<?php
 endif;
 endfor;
 ?>
</div>
<?php echo $peony_footer_home;?>
</section>