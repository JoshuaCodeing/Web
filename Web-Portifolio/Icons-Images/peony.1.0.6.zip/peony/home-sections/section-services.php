<?php
  global $peony_header_home,$peony_footer_home, $allowedposttags;

  $image =  peony_option( 'services_image') ;
  $title = wp_kses(peony_option( 'services_title' ), $allowedposttags);
  $subtitle = wp_kses(peony_option( 'services_subtitle'), $allowedposttags);
  $columns = wp_kses(peony_option( 'services_columns'), $allowedposttags);
  $col = $columns>0?12/$columns:4;
  if( $peony_footer_home != '' )
 $section_class = 'section-footer';
else
 $section_class = '';
?>                
<section class="section section-services <?php echo $section_class;?>">		
<?php echo $peony_header_home; ?>		
				<div class="section-content">
					<div class="container">
						<div class="section-title-wrap text-center">
							<h1 class="section-title peony_services_title"><?php echo $title;?></h1>
							<p class="section-subtitle sm-wrap peony_services_subtitle"><?php echo do_shortcode($subtitle);?></p>
						</div>                        
                        <?php 
									$items = '';
									$item  = '';
									$j = 1;	
		
									for( $i = 1; $i<=8; $i++ ){
										$image = esc_url( peony_option( 'services_image_'.$i));
										$icon  = esc_attr( peony_option( 'services_icon_'.$i));
										$title = '';
										$title_link = '';
										$desc = absint(  peony_option( 'services_desc_'.$i));
										if($desc  > 0 ){
										 $query = new WP_Query( array( 'page_id' => $desc ) );
										  if ( $query->have_posts() ) :
											  while ( $query->have_posts() ) :
												  $query->the_post();
	  
										  $title_link = esc_url(get_permalink($desc));
										  $desc = get_the_content();
										  $title = get_the_title(); 
										  endwhile;
										  endif;
										}
										
									$service_icon = '<i class="fa '.$icon.'"></i>';
									if( $image != '' )
									$service_icon = '<img src="'.$image.'" alt="" />';
										
		                           if( $title!=''){
										$item .= '<div class="col-md-'.$col.'">
													<div class="peony-feature-box">
														<div class="icon peony_services_icon_'.$i.'">'.$service_icon.'</div>
														<h4 class="title "><a href="'.$title_link.'">'.esc_attr($title).'</a></h4>
														<p class="desc">'.do_shortcode($desc).'</p>
													</div>
												</div>';
										
                            	  if( $j % $columns == 0 ){
												$items .= '<div class="row">'.$item.'</div>';
												$item   = '';
										   }
	   
										$j++;
										}
										}
										 if( $item != '' ){
											  $items .= '<div class="row">'.$item.'</div>';
											  }
											  echo $items;
										?>
                                        
						<div class="row">
                        
							
			
							
						</div>
					</div>					
				</div>
                <?php echo $peony_footer_home;?>	
			</section>