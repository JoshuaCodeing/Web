<?php
/**
 * @package peony
 */

get_header(); 
get_template_part('content','home');
get_footer();