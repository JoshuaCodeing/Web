<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @package peony
 */

get_header(); 
?>
<?php
global  $allowedposttags;

$enable_page_title_bar     = peony_option('enable_page_title_bar');
$page_title_pos            = esc_attr(peony_option('page_title_pos'));
$display_breadcrumb        = esc_attr(peony_option('display_breadcrumb'));
$breadcrumb_menu_prefix    = esc_attr(peony_option('breadcrumb_menu_prefix',''));
$breadcrumb_menu_separator = esc_attr(peony_option('breadcrumb_menu_separator','/'));
$content                   = wp_kses(peony_option('content_404'), $allowedposttags);

$sidebar ='none';
$left_sidebar              = esc_attr(peony_option('left_sidebar_404'));
$right_sidebar             = esc_attr(peony_option('right_sidebar_404'));
if( $left_sidebar !='' )
$sidebar ='left';
if( $right_sidebar !='' )
$sidebar ='right';
if( $left_sidebar !='' && $right_sidebar !='' )
$sidebar ='both';
?>
<?php if( $enable_page_title_bar == '1' ):?>
<section class="page-title-bar title-<?php echo $page_title_pos;?> no-subtitle peony_enable_page_title_bar">
            <div class="container">
                <hgroup class="page-title text-light">
                    <h1 class="peony_title_404"><?php echo esc_attr(peony_option('title_404'));?></h1>
                </hgroup>
                <?php if( $display_breadcrumb == '1' ):?>
                <?php peony_get_breadcrumb(array("before"=>"<div class='breadcrumb-nav text-light peony_display_breadcrumb'>".$breadcrumb_menu_prefix,"after"=>"</div>","show_browse"=>false,"separator"=>$breadcrumb_menu_separator));?>
                <?php endif;?>
                
                <div class="clearfix"></div>            
            </div>
        </section>
<?php endif;?>
<div class="page-wrap">
            <div class="container">
                <div class="page-inner row <?php echo peony_get_content_class($sidebar);?>">
                    <div class="col-main">
                        <section class="page-main" role="main" id="content">
                            <div class="page-content peony_content_404">
                               <?php echo  do_shortcode($content);?>
                            </div>
                            <div class="post-attributes"></div>
                        </section>
                    </div>
                    
                    <?php if( $sidebar == 'left' || $sidebar == 'both'  ): ?>
       <div class="col-aside-left">
                        <aside class="blog-side left text-left">
                            <div class="widget-area">
                            <?php get_sidebar('notfoundleft');?>
                            </div>
                        </aside>
                    </div>
            <?php endif; ?>
            <?php if( $sidebar == 'right' || $sidebar == 'both'  ): ?>        
                    <div class="col-aside-right">
                        <div class="widget-area">
                           <?php get_sidebar('notfoundright');?>
                            </div>
                    </div>
             <?php endif; ?>
             
                </div>
            </div>  
        </div>        
<!-- #primary -->

<?php get_footer(); ?>
