<?php
/**
 * @package peony
 */

get_header(); 
$left_sidebar    = peony_option('left_sidebar_blog_archive');
$right_sidebar   = peony_option('right_sidebar_blog_archive');
$sidebar         = 'none';

if( $left_sidebar )
$sidebar = 'left';
if( $right_sidebar )
$sidebar = 'right';
if( $left_sidebar && $right_sidebar )
$sidebar = 'both';

$layout          = peony_option('layout');
$container       = 'container';
if( $layout == 'wide' )
$container  = 'container-fullwidth';
?>
<!--Main Area-->
        <section class="page-title-bar title-left no-subtitle peony_enable_page_title_bar">
            <div class="container">
                <hgroup class="page-title text-light">
                    <h1><?php single_cat_title(__('Currently browsing','peony')); ?> </h1>
                    <?php if(peony_option('blog_subtitle')):?>
                    <h3 class="peony_blog_subtitle"><?php echo esc_attr(peony_option('blog_subtitle'));?></h3>
                    <?php endif;?>
                </hgroup>
                    
                <div class="clearfix"></div>            
            </div>
        </section>

	   <div class="page-wrap">
            <div class="<?php echo $container;?>">
                <div class="page-inner row <?php echo peony_get_content_class($sidebar);?>">
                    <div class="col-main">
                        <section class="page-main" role="main" id="content">
                            <div class="page-content">
                                <!--blog list begin-->
                                <div class="blog-list-wrap">

		<?php if ( have_posts() ) : ?>

			<?php /* Start the Loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', 'search'); ?>

			<?php endwhile; ?>

			<?php peony_paging_nav('echo'); ?>

		<?php else : ?>

			<?php get_template_part( 'content', 'none' ); ?>

		<?php endif; ?>

		</div><!-- #blog-list-wrap -->
	  </div><!-- #page-content -->
       <div class="post-attributes"></div>
    </section><!-- #page-main -->
    </div><!-- #col-main -->
    
    <?php if( $sidebar == 'left' || $sidebar == 'both'  ): ?>
    <div class="col-aside-left">
                        <aside class="blog-side left text-left">
                            <div class="widget-area">
                            <?php get_sidebar('archiveleft');?>
                            </div>
                        </aside>
                    </div>
            <?php endif; ?>
            <?php if( $sidebar == 'right' || $sidebar == 'both'  ): ?>        
                    <div class="col-aside-right">
                        <div class="widget-area">
                           <?php get_sidebar('archiveright');?>
                            </div>
                    </div>
             <?php endif; ?>
                    <!-- #col-side -->
    </div><!-- #page-inner -->
    </div><!-- #container -->
    </div><!-- #page-wrap -->

<?php get_footer(); ?>