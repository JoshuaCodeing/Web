# jquery.backgroundMove.js
This plugin will move your background image on mouse move

#Usage
$('element').backgroundMove();

##Options
####movementStrength
$('element').backgroundMove({
  movementStrength:'50'
});

